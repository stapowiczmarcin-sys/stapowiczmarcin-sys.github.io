#pragma once
// VEGA 2.0 — independent time and effect layers; EN/PL web panel.
// ================================================================
//  VEGA ZEGAR LED — ESP8266
//  WWW + OTA + mDNS + NTP (UK BST) + OLED + NeoPixel
//  SinricPro (Switch) zamiast Espalexa
// ================================================================
// ====== SINRIC (ESP8266 tip: mniej RAM bez SSL) ======
#define SINRICPRO_NOSSL
#include <SinricPro.h>
#include <SinricProSwitch.h>
// ====== Twoje dane SinricPro ======
// Value moved to Config.h
// Value moved to Config.h
// Value moved to Config.h
#include <Adafruit_NeoPixel.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <ESP8266WiFi.h>
#include <ESP8266WebServer.h>
#include <ESP8266mDNS.h>
#include <WiFiUdp.h>
#include "VegaTime.h"
#include <time.h>
#include <ArduinoOTA.h>
#include <ESP8266HTTPUpdateServer.h>
#include <EEPROM.h>
#include <math.h>
#include "Config.h"
#include "ClockRender.h"
#include "WebUI.h"
// ======================== USTAWIENIA SIECI ===========================
// Value moved to Config.h
// Value moved to Config.h
// Value moved to Config.h
const char* mdnsName    = "zegar"; // -> http://zegar.local
// ======================== NTP UK =====================================
VegaTimeClient timeClient("europe.pool.ntp.org");
int currentOffsetSeconds = 0;
// ======================== LED ========================================
#define PIN D2
#define NUMPIXELS 137
Adafruit_NeoPixel pixels(NUMPIXELS, PIN, NEO_GRB + NEO_KHZ800);
// ======================== OLED =======================================
#define SDA_PIN D5
#define SCL_PIN D6
#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define OLED_RESET -1
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);
// ======================== WWW + OTA ==================================
ESP8266WebServer server(80);
ESP8266HTTPUpdateServer httpUpdater;
// ======================== USTAWIENIA / STAN ==========================
bool lampOn = true;   // efekty/tło
bool clockOn = true;  // overlay czasu
int  mode = 1;        // 0: Only Clock, 1: Clock+Effects, 2: Only Effects
int  currentEffectIndex = 20;
uint8_t  brightness = 155;        // jasność efektów (global)
uint32_t backgroundColor = 0;
uint32_t clockColor = 0; // legacy
// osobne kolory H/M/S
uint32_t hourColor = 0;
uint32_t minuteColor = 0;
uint32_t secondColor = 0;
// jasność zegara (overlay)
uint8_t clockIntensity = 255;
uint8_t clockIntensityDefault = 255;
// ======================== Opcjonalny gradient dla Clock+Effects =================
bool premiumBgOn = true;          // ON/OFF premium gradient
uint8_t premiumBgBrightness = 60; // 2..255
uint8_t premiumBgSpeed = 18;      // 3..60 (większa = wolniej)
uint8_t premiumBgSat = 190;
uint16_t premiumBgPhase = 0;
// ======================== Mega kometa ================================
struct MegaCometCfg {
  uint8_t enabled = 1;
  uint8_t tailLen = 90;
  uint8_t headBright = 255;
  uint8_t tailMinBright = 6;
  uint16_t durationMs = 5200;
  uint8_t glitter = 1;
} megaCometCfg;
bool megaCometActive=false;
unsigned long megaCometStartMs=0;
unsigned long megaCometEndMs=0;
// ======================== Efekty ====================================
const char* effectNames[] = {
  "Random Color Wipe","Color Wipe","Green Wipe","Sparkle Stars",
  "Red Wipe","Dim Red Wipe","Blue Wipe","Bidirectional Wipe",
  "Reverse Wipe","Breathing Glow","Gradient Fill","Ping Pong",
  "Random Flicker","Sine Wave","Color Burst","Twinkling Stars",
  "Chasing Arrows","Fireworks","Spinning Fractal","Fireworks Sparkle",
  "Rainbow Cycle","Theater Chase","Meteor Shower","Twinkle",
  "Comet","Color Bounce","Aurora","Embers","Orbit"
};
const int EFFECT_COUNT = 29;
struct AnimState {
  int step=0, phase=0, dir=1, aux=0, aux2=0;
  unsigned long lastUpdate=0;
  bool active=false;
} anim;
// ======================== Harmonogram lampy ==========================
struct Schedule2DimCfg {
  uint8_t enabled=1;
  uint8_t dim1H=10, dim1M=0;
  uint8_t dim1Percent=15;
  uint8_t dim2H=11, dim2M=0;
  uint8_t dim2Percent=5;
  uint8_t offH=12, offM=0;
  uint8_t onH =17, onM =0;
};
Schedule2DimCfg schedWeek;
Schedule2DimCfg schedWeekend;
// ======================== Harmonogram ZEGARA (overlay) ================
struct ClockScheduleCfg {
  uint8_t enabled = 1;
  uint8_t dimH=22, dimM=0;
  uint8_t dimPercent=20;
  uint8_t offH=23, offM=30;
  uint8_t onH=6, onM=30;
};
ClockScheduleCfg clockSchedWeek;
ClockScheduleCfg clockSchedWeekend;
// ======================== Kalibracja 12 cyfr =========================
struct Calib12Cfg {
  uint8_t enabled=1;
  uint16_t mark[12];
} calib12;
// ======================== EEPROM =====================================
const uint32_t EEPROM_MAGIC = 0x5A474352; // "ZGCR"
struct Persist {
  uint32_t magic;
  uint8_t lampOn;
  uint8_t clockOn;
  uint8_t mode;
  uint8_t effect;
  uint8_t brightness;
  uint32_t backgroundColor;
  uint32_t clockColor;
  uint32_t hourColor;
  uint32_t minuteColor;
  uint32_t secondColor;
  uint8_t clockIntensityDefault;
  uint8_t premiumBgOn;
  uint8_t premiumBgBrightness;
  Schedule2DimCfg week;
  Schedule2DimCfg weekend;
  ClockScheduleCfg clockWeek;
  ClockScheduleCfg clockWeekend;
  MegaCometCfg mega;
  Calib12Cfg calib12;
};
Persist persist;
// Separate buffers prevent time markers leaking into effect history.
uint32_t effectPixels[NUMPIXELS] = {};
uint32_t composedPixels[NUMPIXELS] = {};
bool contrastProtection = true, showSecondsHand = true, uiPolish = false;
uint8_t effectIntensityDefault=155;
bool configuredClockOn=true, configuredLampOn=true;
bool pendingSave = false;
unsigned long saveRequestedMs = 0;
int previewLed = -1;
unsigned long previewStartedMs = 0;
struct ExtraPersist { uint32_t magic; uint8_t protect, seconds, polish; };
static_assert(sizeof(Persist)<512, "Legacy EEPROM block overlaps extension");
void savePersist();
void saveExtraPersist();

// ======================== Anti-flicker ===============================
static const uint16_t FRAME_MS = 25; // ~40 FPS
static unsigned long lastFrameMs = 0;
// ======================== SINRIC STATE ===============================
// W SinricPro 4.x na ESP8266: SinricPro[ID] zwraca Proxy (rvalue) => NIE bierzemy &
// Trzymamy wskaźnik na bazowy typ urządzenia:
SinricProDevice* g_sinricDev = nullptr;
static bool g_lastSinricReported = true;
static inline bool sinricPowerNow() {
  return (mode != 0 && lampOn) || (mode != 2 && clockOn);
}
static void syncSinricPowerIfChanged() {
  if (!g_sinricDev) return;
  bool p = sinricPowerNow();
  if (p == g_lastSinricReported) return;
  g_lastSinricReported = p;
  // event power: jest na Switch (i ogólnie na urządzeniach z capability PowerState)
  // Wysyłamy przez cast do SinricProSwitch:
  ((SinricProSwitch*)g_sinricDev)->sendPowerStateEvent(p);
}
// ======================== Helpers ====================================
static inline int wrapPix(int p){ while(p<0)p+=NUMPIXELS; while(p>=NUMPIXELS)p-=NUMPIXELS; return p; }
String two(int v){ return v<10 ? "0"+String(v) : String(v); }
uint32_t Wheel(byte WheelPos) {
  WheelPos = 255 - WheelPos;
  if (WheelPos < 85) return pixels.Color(255 - WheelPos*3, 0, WheelPos*3);
  if (WheelPos < 170) { WheelPos -= 85; return pixels.Color(0, WheelPos*3, 255 - WheelPos*3); }
  WheelPos -= 170;
  return pixels.Color(WheelPos*3, 255 - WheelPos*3, 0);
}
uint32_t dimColor(uint32_t color, int br) {
  br = constrain(br, 0, 255);
  int r = ((color>>16)&0xFF) * br / 255;
  int g = ((color>>8 )&0xFF) * br / 255;
  int b = ( color &0xFF) * br / 255;
  return pixels.Color(r,g,b);
}
uint32_t blendColor(uint32_t c1, uint32_t c2, float f) {
  f = constrain(f, 0.0f, 1.0f);
  int r1=(c1>>16)&0xFF, g1=(c1>>8)&0xFF, b1=c1&0xFF;
  int r2=(c2>>16)&0xFF, g2=(c2>>8)&0xFF, b2=c2&0xFF;
  int r=r1+(int)((r2-r1)*f);
  int g=g1+(int)((g2-g1)*f);
  int b=b1+(int)((b2-b1)*f);
  return pixels.Color(r,g,b);
}
static inline void fadeAll(uint8_t factor){
  for(int i=0;i<NUMPIXELS;i++){
    uint32_t c = pixels.getPixelColor(i);
    uint8_t r = ((c>>16)&0xFF) * factor / 255;
    uint8_t g = ((c>>8 )&0xFF) * factor / 255;
    uint8_t b = ( c &0xFF) * factor / 255;
    pixels.setPixelColor(i, pixels.Color(r,g,b));
  }
}
static inline void fillAll(uint32_t c){ for(int i=0;i<NUMPIXELS;i++) pixels.setPixelColor(i, c); }
static inline void hardOff(){ fillAll(0); pixels.show(); }
// HSV -> RGB
static inline uint32_t hsv8(uint8_t h, uint8_t s, uint8_t v){
  uint8_t region = h / 43;
  uint8_t remainder = (h - region * 43) * 6;
  uint8_t p = (uint16_t)v * (255 - s) / 255;
  uint8_t q = (uint16_t)v * (255 - ((uint16_t)s * remainder) / 255) / 255;
  uint8_t t = (uint16_t)v * (255 - ((uint16_t)s * (255 - remainder)) / 255) / 255;
  uint8_t r,g,b;
  switch(region){
    default:
    case 0: r=v; g=t; b=p; break;
    case 1: r=q; g=v; b=p; break;
    case 2: r=p; g=v; b=t; break;
    case 3: r=p; g=q; b=v; break;
    case 4: r=t; g=p; b=v; break;
    case 5: r=v; g=p; b=q; break;
  }
  return pixels.Color(r,g,b);
}
// ======================== BST UK =====================================
static int daysInMonth(int y,int m){
  static const int d[12]={31,28,31,30,31,30,31,31,30,31,30,31};
  int leap = ( (y%4==0 && y%100!=0) || (y%400==0) ) ? 1:0;
  return m==2? d[m-1]+leap : d[m-1];
}
static int weekday_calc(int y,int m,int d){
  static int t[]={0,3,2,5,0,3,5,1,4,6,2,4};
  if(m<3) y-=1;
  return (y + y/4 - y/100 + y/400 + t[m-1] + d) % 7; // 0=Sun
}
bool isBST_UK(time_t utc){
  struct tm *tm = gmtime(&utc);
  int y=tm->tm_year+1900, m=tm->tm_mon+1, d=tm->tm_mday, h=tm->tm_hour;
  int marchLast = daysInMonth(y,3);
  int wMar = weekday_calc(y,3,marchLast);
  int lastSunMar = marchLast - wMar;
  int octLast = daysInMonth(y,10);
  int wOct = weekday_calc(y,10,octLast);
  int lastSunOct = octLast - wOct;
  if(m<3 || m>10) return false;
  if(m>3 && m<10) return true;
  if(m==3){
    if(d>lastSunMar) return true;
    if(d<lastSunMar) return false;
    return h>=1;
  }
  if(m==10){
    if(d<lastSunOct) return true;
    if(d>lastSunOct) return false;
    return h<1;
  }
  return false;
}
void refreshUKOffset(){
  time_t epochLocal = timeClient.getEpochTime();
  time_t epochUTC = epochLocal - currentOffsetSeconds;
  int newOff = isBST_UK(epochUTC) ? 3600 : 0;
  if(newOff != currentOffsetSeconds){
    currentOffsetSeconds = newOff;
    timeClient.setTimeOffset(currentOffsetSeconds);
  }
}
int getWdayLocal(time_t localEpoch){
  struct tm *t = localtime(&localEpoch);
  return t ? t->tm_wday : 0; // 0=Sun
}
static inline bool isWeekend(int wday){ return (wday==0 || wday==6); }
// ======================== Mapowanie czasu -> LED =====================
int mapFracToLed(float frac){
  while(frac < 0) frac += 1.0f;
  while(frac >= 1.0f) frac -= 1.0f;
  if(calib12.enabled){
    float x = frac * 12.0f;
    int seg = (int)floorf(x);
    float t = x - seg;
    int a = seg;
    int b = (seg + 1) % 12;
    uint16_t from = calib12.mark[a];
    uint16_t to = calib12.mark[b];
    int d = (int)to - (int)from;
    if(d < 0) d += NUMPIXELS;
    int move = (int)lroundf(d * t);
    return wrapPix((int)from + move);
  }
  float ff = frac - 0.5f;
  while(ff < 0) ff += 1.0f;
  int idx = (int)lroundf(ff * NUMPIXELS) % NUMPIXELS;
  return wrapPix(idx);
}
static inline void paintDot(int pos, uint32_t col, int thick){
  thick = constrain(thick, 1, 6);
  pos = wrapPix(pos);
  pixels.setPixelColor(pos, col);
  for(int i=1;i<thick;i++){
    float f = 1.0f - (i/(float)thick);
    int p1 = wrapPix(pos+i);
    int p2 = wrapPix(pos-i);
    pixels.setPixelColor(p1, blendColor(pixels.getPixelColor(p1), col, 0.55f*f));
    pixels.setPixelColor(p2, blendColor(pixels.getPixelColor(p2), col, 0.55f*f));
  }
}
static inline void paintTail(int pos, uint32_t col, int tailLen){
  tailLen = constrain(tailLen, 0, 80);
  for(int t=1;t<=tailLen;t++){
    float f = 1.0f - (t/(float)(tailLen+1));
    uint32_t c = dimColor(col, (int)(255*f));
    int p = wrapPix(pos - t);
    pixels.setPixelColor(p, blendColor(pixels.getPixelColor(p), c, 0.65f));
  }
}
// ======================== Overlay czasu ==============================
void overlayTime(int h,int m,int s){
  int positions[3] = { mapFracToLed(((h%12)+m/60.0f+s/3600.0f)/12.0f),
    mapFracToLed((m+s/60.0f)/60.0f), mapFracToLed(s/60.0f) };
  uint32_t colors[3] = {hourColor,minuteColor,secondColor};
  for(int i=0;i<NUMPIXELS;i++) composedPixels[i]=pixels.getPixelColor(i);
  VegaRender::compose(composedPixels, composedPixels, NUMPIXELS, mode,
    clockOn, lampOn, timeClient.isTimeSet(), brightness, clockIntensity,
    positions, colors, contrastProtection, showSecondsHand);
  for(int i=0;i<NUMPIXELS;i++) pixels.setPixelColor(i,composedPixels[i]);
}

// ======================== Mega kometa ================================
static inline float smoothstep(float x){ x = constrain(x,0.0f,1.0f); return x*x*(3.0f-2.0f*x); }
void megaCometTrigger(){
  if(!megaCometCfg.enabled || mode!=1 || !clockOn || !lampOn || !timeClient.isTimeSet()) return;
  megaCometActive = true;
  megaCometStartMs = millis();
  megaCometEndMs = megaCometStartMs + (unsigned long)megaCometCfg.durationMs;
}
void megaCometDraw(){
  if(!megaCometActive) return;
  if(mode!=1 || !clockOn || !lampOn){ megaCometActive=false; return; }
  unsigned long now = millis();
  if((unsigned long)(now-megaCometStartMs) >= megaCometCfg.durationMs){
    megaCometActive=false;
    return;
  }
  float t = (now - megaCometStartMs) / (float)(megaCometCfg.durationMs);
  t = smoothstep(t);
  uint32_t base = blendColor(hourColor, minuteColor, 0.5f);
  base = blendColor(base, secondColor, 0.35f);
  base = blendColor(base, pixels.Color(255,255,255), 0.12f);
  int head = wrapPix((int)lroundf(t * (NUMPIXELS - 1)));
  uint32_t headCol = dimColor(base, (int)((megaCometCfg.headBright * 255) / 255));
  pixels.setPixelColor(head, blendColor(pixels.getPixelColor(head), headCol, 0.93f));
  int tail = constrain((int)megaCometCfg.tailLen, 10, 140);
  for(int i=1;i<=tail;i++){
    float f = 1.0f - (i/(float)(tail+1));
    uint32_t shifted = blendColor(base, Wheel((uint8_t)(i*3)), 0.10f * (1.0f-f));
    int br = (int)(megaCometCfg.tailMinBright + f * (megaCometCfg.headBright - megaCometCfg.tailMinBright));
    br = (int)((br * 255) / 255);
    uint32_t c = dimColor(shifted, br);
    int p = wrapPix(head - i);
    pixels.setPixelColor(p, blendColor(pixels.getPixelColor(p), c, 0.88f));
    if(megaCometCfg.glitter && (random(0,1000) < (int)(6 + 40*f))){
      uint32_t g = dimColor(pixels.Color(255,255,255), (int)(255 * (0.10f + 0.25f*f)));
      pixels.setPixelColor(p, blendColor(pixels.getPixelColor(p), g, 0.25f));
    }
  }
}
// ======================== Optional gradient (Clock+Effects) ============
void updatePremiumBackground(){
  premiumBgPhase++;
  uint16_t phase = premiumBgPhase;
  uint8_t v = premiumBgBrightness;
  uint8_t s = premiumBgSat;
  for(int i=0;i<NUMPIXELS;i++){
    uint8_t h = (uint8_t)((i * 256UL / NUMPIXELS) + (phase / max((int)premiumBgSpeed, 1)));
    float k = 0.75f + 0.25f * sinf((i / (float)NUMPIXELS) * 6.2831853f);
    uint8_t vv = (uint8_t)constrain((int)(v * k), 0, 255);
    uint32_t c = hsv8(h, s, vv);
    c = blendColor(0, c, 0.78f);
    pixels.setPixelColor(i, c);
  }
  if((phase % 17) == 0 && random(0,100) < 18){
    int p = random(0, NUMPIXELS);
    uint32_t b = dimColor(pixels.Color(255,255,255), (int)(premiumBgBrightness * 0.18f));
    pixels.setPixelColor(p, blendColor(pixels.getPixelColor(p), b, 0.22f));
  }
}
// ======================== Efekty ====================================
void startEffect(int e){
  currentEffectIndex = constrain(e, 0, EFFECT_COUNT-1);
  anim = AnimState();
  memset(effectPixels,0,sizeof(effectPixels));
  anim.active = true;
  anim.lastUpdate = millis();
  anim.aux = random(0,255);
  anim.aux2 = random(0,255);
}
void ensureEffectRunning(){
  if((mode == 1 || mode == 2) && lampOn){
    if(!anim.active) startEffect(currentEffectIndex);
  }
}
void updateEffect(){
  if(!anim.active) return;
  unsigned long now=millis();
  if(now-anim.lastUpdate<FRAME_MS) return;
  anim.lastUpdate=now;
  const int step=anim.step;
  const float phase=step*0.025f;
  const uint32_t tint=Wheel((uint8_t)(anim.aux+step/5));
  // Wipes retain their own history. Other scenes build a fresh or fading frame.
  switch(currentEffectIndex){
    case 0: case 1: case 2: case 4: case 5: case 6: case 7: case 8: {
      int p=(step/2)%(NUMPIXELS+20);
      if(p==0 && step%2==0){ fillAll(0); if(currentEffectIndex==0)anim.aux=random(256); }
      uint32_t c=currentEffectIndex==2?pixels.Color(0,255,100):
        currentEffectIndex==4?pixels.Color(255,12,0):
        currentEffectIndex==5?pixels.Color(90,5,0):
        currentEffectIndex==6?pixels.Color(0,100,255):tint;
      if(p<NUMPIXELS){pixels.setPixelColor(currentEffectIndex==8?NUMPIXELS-1-p:p,c);
        if(currentEffectIndex==7)pixels.setPixelColor(NUMPIXELS-1-p,c);}
    }break;
    case 3: case 12: case 15: case 23: {
      fadeAll(currentEffectIndex==12?200:242);
      if(step%(currentEffectIndex==15?3:2)==0){
        int p=random(NUMPIXELS);uint32_t c=currentEffectIndex==3?pixels.Color(220,235,255):tint;
        pixels.setPixelColor(p,dimColor(c,random(90,256)));
      }
    }break;
    case 9: fillAll(dimColor(tint,(int)(12+243*(0.5f+0.5f*sinf(phase)))));break;
    case 10: case 13: case 18: case 20: case 26: case 27: {
      for(int i=0;i<NUMPIXELS;i++){
        float x=i*6.2831853f/NUMPIXELS;
        uint32_t c;
        if(currentEffectIndex==26){
          float wave=0.5f+0.5f*sinf(x*2-phase*0.35f+0.7f*sinf(x*3+phase*0.2f));
          c=blendColor(pixels.Color(4,20,95),pixels.Color(20,255,125),wave);
          c=blendColor(c,pixels.Color(130,25,230),0.2f+0.2f*sinf(x-phase*0.15f));
        }else if(currentEffectIndex==27){
          float heat=0.5f+0.5f*sinf(x*4+phase*0.35f)*sinf(x*2-phase*0.45f);
          c=pixels.Color((int)(70+180*heat),(int)(3+65*heat*heat),0);
        }else{
          c=Wheel((uint8_t)(i*256/NUMPIXELS+step/(currentEffectIndex==10?8:3)));
          if(currentEffectIndex==13)c=dimColor(c,(int)(15+240*(0.5f+0.5f*sinf(x*3-phase))));
          if(currentEffectIndex==18)c=dimColor(c,(int)(20+235*fabsf(sinf(x*3+phase)*cosf(x*2-phase))));
        }
        pixels.setPixelColor(i,c);
      }
    }break;
    case 11: case 25: {
      fadeAll(210); int span=2*(NUMPIXELS-1);int p=(step/2)%span;
      if(p>=NUMPIXELS)p=span-p;
      pixels.setPixelColor(p,tint);pixels.setPixelColor(wrapPix(p+1),dimColor(tint,90));
    }break;
    case 14: case 17: case 19: {
      fadeAll(225);const int age=step%100;
      if(age==0){anim.aux=random(NUMPIXELS);anim.aux2=random(256);}
      const uint32_t c=Wheel((uint8_t)anim.aux2);
      if(age<45){int r=age/2;uint32_t dim=dimColor(c,255-age*5);
        pixels.setPixelColor(wrapPix(anim.aux+r),dim);pixels.setPixelColor(wrapPix(anim.aux-r),dim);
        if(currentEffectIndex==14)pixels.setPixelColor(wrapPix(anim.aux+r+NUMPIXELS/2),dim);
        if(currentEffectIndex==19 && age%3==0)pixels.setPixelColor(random(NUMPIXELS),pixels.Color(255,180,70));}
    }break;
    case 16: case 21: {
      fillAll(0);int spacing=currentEffectIndex==16?17:3;
      for(int i=0;i<NUMPIXELS;i++)if((i+step/3)%spacing< (currentEffectIndex==16?4:1))
        pixels.setPixelColor(i,dimColor(tint,currentEffectIndex==16?255-((i+step/3)%spacing)*55:220));
    }break;
    case 22: case 24: case 28: {
      fadeAll(currentEffectIndex==28?226:235);
      int head=(step/(currentEffectIndex==28?3:1))%NUMPIXELS;
      for(int t=0;t<12;t++)pixels.setPixelColor(wrapPix(head-t),dimColor(tint,255-t*21));
      if(currentEffectIndex==22 || currentEffectIndex==28){
        int p=wrapPix(NUMPIXELS-1-head+NUMPIXELS/2);
        pixels.setPixelColor(p,pixels.Color(30,130,255));
      }
    }break;
    default: fillAll(0);break;
  }
  anim.step=(step+1)%12000;
}

// ======================== Harmonogram (lamp) ==========================
static inline void applyBrightnessPercent(uint8_t percent){
  percent = constrain(percent, 1, 100);
  int br = (int)lroundf(255.0f * (percent/100.0f));
  br = constrain(br, 2, 255);
  brightness = (uint8_t)br;
  pixels.setBrightness(255);
}
void applySchedule2Dim(const Schedule2DimCfg& sc, int hour, int minute){
  if(!sc.enabled) return;
  int md = hour*60 + minute;
  int dim1MD = sc.dim1H*60 + sc.dim1M;
  int dim2MD = sc.dim2H*60 + sc.dim2M;
  int offMD  = sc.offH *60 + sc.offM;
  int onMD   = sc.onH  *60 + sc.onM;
  if(md==dim1MD) applyBrightnessPercent(sc.dim1Percent);
  if(md==dim2MD) applyBrightnessPercent(sc.dim2Percent);
  if(md==offMD){
    lampOn = false;
    anim.active = false;
  }
  if(md==onMD){
    lampOn = true;
    brightness = effectIntensityDefault;
    pixels.setBrightness(255);
    startEffect(currentEffectIndex);
  }
}
// ======================== Harmonogram ZEGARA ==========================
static inline uint8_t percentTo255(uint8_t percent){
  percent = constrain(percent, 1, 100);
  int v = (int)lroundf(255.0f * (percent/100.0f));
  return (uint8_t)constrain(v, 2, 255);
}
void applyClockSchedule(const ClockScheduleCfg& sc, int hour, int minute){
  if(!sc.enabled) return;
  int md = hour*60 + minute;
  int dimMD = sc.dimH*60 + sc.dimM;
  int offMD = sc.offH*60 + sc.offM;
  int onMD  = sc.onH *60 + sc.onM;
  if(md==dimMD){
    clockIntensity = percentTo255(sc.dimPercent);
  }
  if(md==offMD){
    clockOn = false;
  }
  if(md==onMD){
    clockOn = true;
    clockIntensity = clockIntensityDefault;
  }
}
// ======================== EEPROM load/save ============================
static inline bool validH(uint8_t h){ return h <= 23; }
static inline bool validM(uint8_t m){ return m <= 59; }
static inline uint8_t safePct(uint8_t p, uint8_t defv){ return (p>=1 && p<=100) ? p : defv; }
void loadPersist(){
  EEPROM.begin(4096);
  EEPROM.get(0, persist);
  if(persist.magic != EEPROM_MAGIC){
    memset(&persist, 0, sizeof(persist));
    persist.magic = EEPROM_MAGIC;
    persist.lampOn = 1;
    persist.clockOn = 1;
    persist.mode = 1;
    persist.effect = 20;
    persist.brightness = 155;
    persist.backgroundColor = pixels.Color(25,0,40);
    persist.clockColor = pixels.Color(0,255,0);
    persist.hourColor = pixels.Color(255, 174, 50);
    persist.minuteColor = pixels.Color(41, 236, 255);
    persist.secondColor = pixels.Color(255, 56, 85);
    persist.clockIntensityDefault = 255;
    persist.premiumBgOn = 1;
    persist.premiumBgBrightness = 60;
    // WEEK lamp
    persist.week.enabled=1;
    persist.week.dim1H=10; persist.week.dim1M=0; persist.week.dim1Percent=15;
    persist.week.dim2H=11; persist.week.dim2M=0; persist.week.dim2Percent=5;
    persist.week.offH =12; persist.week.offM =0;
    persist.week.onH =17;  persist.week.onM =0;
    // WEEKEND lamp
    persist.weekend.enabled=1;
    persist.weekend.dim1H=12; persist.weekend.dim1M=0; persist.weekend.dim1Percent=18;
    persist.weekend.dim2H=1;  persist.weekend.dim2M=0; persist.weekend.dim2Percent=8;
    persist.weekend.offH =2;  persist.weekend.offM =0;
    persist.weekend.onH =17;  persist.weekend.onM =0;
    // WEEK clock
    persist.clockWeek.enabled=1;
    persist.clockWeek.dimH=22; persist.clockWeek.dimM=0; persist.clockWeek.dimPercent=20;
    persist.clockWeek.offH=23; persist.clockWeek.offM=30;
    persist.clockWeek.onH=6;   persist.clockWeek.onM=30;
    // WEEKEND clock
    persist.clockWeekend = persist.clockWeek;
    // Mega comet
    persist.mega.enabled=1;
    persist.mega.tailLen=90;
    persist.mega.headBright=255;
    persist.mega.tailMinBright=6;
    persist.mega.durationMs=5200;
    persist.mega.glitter=1;
    // Kalibracja 12
    persist.calib12.enabled = 1;
    persist.calib12.mark[0] = 74;
    persist.calib12.mark[1] = 88;
    persist.calib12.mark[2] = 95;
    persist.calib12.mark[3] = 106;
    persist.calib12.mark[4] = 118;
    persist.calib12.mark[5] = 125;
    persist.calib12.mark[6] = 1;
    persist.calib12.mark[7] = 13;
    persist.calib12.mark[8] = 24;
    persist.calib12.mark[9] = 36;
    persist.calib12.mark[10] = 52;
    persist.calib12.mark[11] = 58;
    EEPROM.put(0, persist);
    EEPROM.commit();
  }
  lampOn = persist.lampOn;
  clockOn = persist.clockOn;
  mode = constrain((int)persist.mode,0,2);
  currentEffectIndex = constrain((int)persist.effect, 0, EFFECT_COUNT-1);
  brightness = persist.brightness;
  effectIntensityDefault=brightness;configuredClockOn=clockOn;configuredLampOn=lampOn;
  backgroundColor = persist.backgroundColor;
  clockColor = persist.clockColor;
  hourColor = persist.hourColor;
  minuteColor = persist.minuteColor;
  secondColor = persist.secondColor;
  clockIntensityDefault = (persist.clockIntensityDefault == 0) ? 255 : persist.clockIntensityDefault;
  clockIntensity = clockIntensityDefault;
  premiumBgOn = (persist.premiumBgOn ? true : false);
  premiumBgBrightness = (persist.premiumBgBrightness < 2 ? 60 : persist.premiumBgBrightness);
  schedWeek = persist.week;
  schedWeekend = persist.weekend;
  clockSchedWeek = persist.clockWeek;
  clockSchedWeekend = persist.clockWeekend;
  if(!validH(clockSchedWeek.dimH)) clockSchedWeek.dimH=22;
  if(!validM(clockSchedWeek.dimM)) clockSchedWeek.dimM=0;
  clockSchedWeek.dimPercent = safePct(clockSchedWeek.dimPercent, 20);
  if(!validH(clockSchedWeek.offH)) clockSchedWeek.offH=23;
  if(!validM(clockSchedWeek.offM)) clockSchedWeek.offM=30;
  if(!validH(clockSchedWeek.onH))  clockSchedWeek.onH=6;
  if(!validM(clockSchedWeek.onM))  clockSchedWeek.onM=30;
  if(!validH(clockSchedWeekend.dimH)) clockSchedWeekend.dimH=22;
  if(!validM(clockSchedWeekend.dimM)) clockSchedWeekend.dimM=0;
  clockSchedWeekend.dimPercent = safePct(clockSchedWeekend.dimPercent, 20);
  if(!validH(clockSchedWeekend.offH)) clockSchedWeekend.offH=23;
  if(!validM(clockSchedWeekend.offM)) clockSchedWeekend.offM=30;
  if(!validH(clockSchedWeekend.onH))  clockSchedWeekend.onH=6;
  if(!validM(clockSchedWeekend.onM))  clockSchedWeekend.onM=30;
  megaCometCfg = persist.mega;
  if(megaCometCfg.durationMs < 800) megaCometCfg.durationMs = 5200;
  if(megaCometCfg.tailLen < 10) megaCometCfg.tailLen = 90;
  calib12 = persist.calib12;
  const uint16_t defaults[12]={74,88,95,106,118,125,1,13,24,36,52,58};
  for(int i=0;i<12;i++)if(calib12.mark[i]>=NUMPIXELS)calib12.mark[i]=defaults[i];
  ExtraPersist extra;
  EEPROM.get(512,extra);
  if(extra.magic==0x56454732){contrastProtection=extra.protect;showSecondsHand=extra.seconds;uiPolish=extra.polish;}

}
void commitPersist(){
  persist.magic = EEPROM_MAGIC;
  persist.lampOn = configuredLampOn;
  persist.clockOn = configuredClockOn;
  persist.mode = mode;
  persist.effect = currentEffectIndex;
  persist.brightness = effectIntensityDefault;
  persist.backgroundColor = backgroundColor;
  persist.clockColor = clockColor;
  persist.hourColor = hourColor;
  persist.minuteColor = minuteColor;
  persist.secondColor = secondColor;
  persist.clockIntensityDefault = clockIntensityDefault;
  persist.premiumBgOn = premiumBgOn ? 1 : 0;
  persist.premiumBgBrightness = premiumBgBrightness;
  persist.week = schedWeek;
  persist.weekend = schedWeekend;
  persist.clockWeek = clockSchedWeek;
  persist.clockWeekend = clockSchedWeekend;
  persist.mega = megaCometCfg;
  persist.calib12 = calib12;
  EEPROM.put(0, persist);
  saveExtraPersist();
  EEPROM.commit();
}
void saveExtraPersist(){
  ExtraPersist extra={0x56454732,(uint8_t)contrastProtection,(uint8_t)showSecondsHand,(uint8_t)uiPolish};
  EEPROM.put(512,extra);
}
void savePersist(){pendingSave=true;saveRequestedMs=millis();}
void flushPendingSave(){
  if(pendingSave && millis()-saveRequestedMs>=900){pendingSave=false;commitPersist();}
}
// ======================== WWW: parsowanie kolorów ====================
static uint32_t parseHexColor(String hex){
  hex.replace("#","");
  if(hex.length() < 6) return pixels.Color(255,255,255);
  long v = strtol(hex.c_str(), nullptr, 16);
  return pixels.Color((v>>16)&0xFF, (v>>8)&0xFF, v&0xFF);
}
// ======================== WWW: state JSON ============================
String jsonState(){
  String j;
  j.reserve(5200);
  j += "{";
  j += "\"epoch\":"+String(timeClient.getEpochTime())+",";
  j += "\"synced\":"+String(timeClient.isTimeSet()?1:0)+",";
  j += "\"bst\":"+String(currentOffsetSeconds==3600?1:0)+",";
  j += "\"power\":"+String(sinricPowerNow()?1:0)+",";
  j += "\"hourColor\":"+String(hourColor)+",";
  j += "\"minuteColor\":"+String(minuteColor)+",";
  j += "\"secondColor\":"+String(secondColor)+",";
  j += "\"protect\":"+String(contrastProtection?1:0)+",";
  j += "\"showSeconds\":"+String(showSecondsHand?1:0)+",";
  j += "\"effectInt\":"+String(brightness)+",";
  j += "\"language\":\""+String(uiPolish?"pl":"en")+"\",";
  j += "\"pixels\":[";
  for(int i=0;i<NUMPIXELS;i++){j+=String(pixels.getPixelColor(i));if(i<NUMPIXELS-1)j+=",";}
  j += "],";
  const Schedule2DimCfg* lamps[2]={&schedWeek,&schedWeekend};
  for(int n=0;n<2;n++){
    const Schedule2DimCfg &sc=*lamps[n];const String prefix=n?"lsE":"lsW";
    j+="\""+prefix+"_en\":"+String(sc.enabled)+",";
    j+="\""+prefix+"_dim1H\":"+String(sc.dim1H)+",";
    j+="\""+prefix+"_dim1M\":"+String(sc.dim1M)+",";
    j+="\""+prefix+"_dim1P\":"+String(sc.dim1Percent)+",";
    j+="\""+prefix+"_dim2H\":"+String(sc.dim2H)+",";
    j+="\""+prefix+"_dim2M\":"+String(sc.dim2M)+",";
    j+="\""+prefix+"_dim2P\":"+String(sc.dim2Percent)+",";
    j+="\""+prefix+"_offH\":"+String(sc.offH)+",";
    j+="\""+prefix+"_offM\":"+String(sc.offM)+",";
    j+="\""+prefix+"_onH\":"+String(sc.onH)+",";
    j+="\""+prefix+"_onM\":"+String(sc.onM)+",";
  }

  j += "\"lampOn\":" + String(lampOn?1:0) + ",";
  j += "\"clockOn\":" + String(clockOn?1:0) + ",";
  j += "\"mode\":" + String(mode) + ",";
  j += "\"effect\":" + String(currentEffectIndex) + ",";
  j += "\"brightness\":" + String(effectIntensityDefault) + ",";
  j += "\"clockInt\":" + String(clockIntensity) + ",";
  j += "\"clockIntDef\":" + String(clockIntensityDefault) + ",";
  j += "\"pbgOn\":" + String(premiumBgOn?1:0) + ",";
  j += "\"pbgBr\":" + String(premiumBgBrightness) + ",";
  j += "\"mega\":" + String(megaCometCfg.enabled?1:0) + ",";
  j += "\"megaDur\":" + String(megaCometCfg.durationMs) + ",";
  j += "\"megaTail\":" + String(megaCometCfg.tailLen) + ",";
  j += "\"megaGlt\":" + String(megaCometCfg.glitter?1:0) + ",";
  j += "\"csW_en\":" + String(clockSchedWeek.enabled?1:0) + ",";
  j += "\"csW_dimH\":" + String(clockSchedWeek.dimH) + ",";
  j += "\"csW_dimM\":" + String(clockSchedWeek.dimM) + ",";
  j += "\"csW_dimP\":" + String(clockSchedWeek.dimPercent) + ",";
  j += "\"csW_offH\":" + String(clockSchedWeek.offH) + ",";
  j += "\"csW_offM\":" + String(clockSchedWeek.offM) + ",";
  j += "\"csW_onH\":"  + String(clockSchedWeek.onH) + ",";
  j += "\"csW_onM\":"  + String(clockSchedWeek.onM) + ",";
  j += "\"csE_en\":" + String(clockSchedWeekend.enabled?1:0) + ",";
  j += "\"csE_dimH\":" + String(clockSchedWeekend.dimH) + ",";
  j += "\"csE_dimM\":" + String(clockSchedWeekend.dimM) + ",";
  j += "\"csE_dimP\":" + String(clockSchedWeekend.dimPercent) + ",";
  j += "\"csE_offH\":" + String(clockSchedWeekend.offH) + ",";
  j += "\"csE_offM\":" + String(clockSchedWeekend.offM) + ",";
  j += "\"csE_onH\":"  + String(clockSchedWeekend.onH) + ",";
  j += "\"csE_onM\":"  + String(clockSchedWeekend.onM) + ",";
  j += "\"marks\":[";
  for(int i=0;i<12;i++){
    j += String(calib12.mark[i]);
    if(i<11) j += ",";
  }
  j += "]";
  j += "}";
  return j;
}
// ======================== HTML =======================================
// (uwaga: HTML jak wcześniej, nie skracam)
// ======================== WWW handlers ================================
void handleRoot(){server.send_P(200,"text/html; charset=utf-8",VEGA_WEB_UI);}

void handleState(){ server.send(200, "application/json; charset=utf-8", jsonState()); }
void handleToggleLamp(){
  if(mode==0){server.send(409,"text/plain","select ambience mode first");return;}
  lampOn = !lampOn;configuredLampOn=lampOn;
  if(lampOn){
    startEffect(currentEffectIndex);
  } else {
    anim.active = false;
  }
  savePersist();
  syncSinricPowerIfChanged();
  server.send(200,"text/plain; charset=utf-8","OK");
}
void handleToggleClock(){
  if(mode==2){server.send(409,"text/plain","select clock mode first");return;}
  clockOn = !clockOn;configuredClockOn=clockOn;
  savePersist();
  syncSinricPowerIfChanged();
  server.send(200,"text/plain; charset=utf-8","OK");
}
void handleSetMode(){
  if(!server.hasArg("mode")){server.send(400,"text/plain","mode required");return;}
  int requested=server.arg("mode").toInt();
  if(requested<0||requested>2){server.send(400,"text/plain","invalid mode");return;}
  mode=requested;VegaRender::selectMode(mode,clockOn,lampOn);
  configuredClockOn=clockOn;configuredLampOn=lampOn;brightness=effectIntensityDefault;
  clockIntensity=clockIntensityDefault;
  megaCometActive=false;previewLed=-1;
  memset(effectPixels,0,sizeof(effectPixels));
  if(lampOn)startEffect(currentEffectIndex);else anim.active=false;
  savePersist();syncSinricPowerIfChanged();
  server.send(200,"text/plain; charset=utf-8","OK");
}

void handleSetBrightness(){
  if(server.hasArg("b")){
    int b=server.arg("b").toInt();
    brightness = (uint8_t)constrain(b,0,255);effectIntensityDefault=brightness;
    pixels.setBrightness(255);
  }
  savePersist();
  server.send(200,"text/plain; charset=utf-8","OK");
}
void handleSetClockInt(){
  if(server.hasArg("ci")){
    int v=server.arg("ci").toInt();
    clockIntensity = (uint8_t)constrain(v,2,255);
    clockIntensityDefault = clockIntensity;
  }
  savePersist();
  server.send(200,"text/plain; charset=utf-8","OK");
}
void handlePbgToggle(){ premiumBgOn = !premiumBgOn; savePersist(); server.send(200,"text/plain; charset=utf-8", String("OK: premium=")+String(premiumBgOn)); }
void handlePbgBrightness(){
  if(!server.hasArg("b")){ server.send(400,"text/plain; charset=utf-8","ERR"); return; }
  int v = server.arg("b").toInt();
  premiumBgBrightness = (uint8_t)constrain(v,2,255);
  savePersist();
  server.send(200,"text/plain; charset=utf-8","OK");
}
void handleSetEffect(){
  if(server.hasArg("e")){
    int e=server.arg("e").toInt();
    if(e>=0 && e<EFFECT_COUNT){
      startEffect(e);
    }
  }
  savePersist();
  server.send(200,"text/plain; charset=utf-8","OK");
}
void handleSetColor(){
  if(!server.hasArg("which") || !server.hasArg("hex")){ server.send(400,"text/plain; charset=utf-8","ERR"); return; }
  String w = server.arg("which");
  uint32_t c = parseHexColor(server.arg("hex"));
  if(w=="h") hourColor=c;
  else if(w=="m") minuteColor=c;
  else if(w=="s") secondColor=c;
  else { server.send(400,"text/plain; charset=utf-8","ERR which"); return; }
  savePersist();
  server.send(200,"text/plain; charset=utf-8","OK");
}
// Kalibracja
void flashOneLed(uint16_t idx){previewLed=wrapPix(idx);previewStartedMs=millis();}

void handleCalSave(){
  if(!server.hasArg("digit") || !server.hasArg("led")){ server.send(400,"text/plain; charset=utf-8","ERR: digit/led"); return; }
  int d=server.arg("digit").toInt();
  int led=server.arg("led").toInt();
  if(d<0||d>11){ server.send(400,"text/plain; charset=utf-8","ERR: digit 0..11"); return; }
  if(led<0||led>=NUMPIXELS){ server.send(400,"text/plain; charset=utf-8","ERR: led 0.."+String(NUMPIXELS-1)); return; }
  calib12.mark[d]=(uint16_t)led;
  calib12.enabled=1;
  savePersist();
  server.send(200,"text/plain; charset=utf-8","OK: zapisano idx="+String(d)+" -> LED "+String(led));
}
void handleCalPreview(){
  if(!server.hasArg("led")){ server.send(400,"text/plain; charset=utf-8","ERR: led"); return; }
  int led=server.arg("led").toInt();
  if(led<0||led>=NUMPIXELS){ server.send(400,"text/plain; charset=utf-8","ERR: led 0.."+String(NUMPIXELS-1)); return; }
  server.send(200,"text/plain; charset=utf-8","OK: preview LED "+String(led));
  flashOneLed((uint16_t)led);
}
// Mega comet routes
void handleMegaToggle(){ megaCometCfg.enabled = !megaCometCfg.enabled; savePersist(); server.send(200,"text/plain; charset=utf-8", String("OK: mega=")+String(megaCometCfg.enabled)); }
void handleMegaTest(){
  if(mode!=1||!clockOn||!lampOn||!megaCometCfg.enabled||!timeClient.isTimeSet()){
    server.send(409,"text/plain","Comet requires clock and ambience mode with synced time");return;
  }
  megaCometTrigger();server.send(200,"text/plain","OK");
}

void handleMegaDur(){ if(server.hasArg("ms")){ int ms = server.arg("ms").toInt(); megaCometCfg.durationMs = (uint16_t)constrain(ms, 1200, 9000); savePersist(); server.send(200,"text/plain; charset=utf-8","OK"); } else server.send(400,"text/plain; charset=utf-8","ERR"); }
void handleMegaTail(){ if(server.hasArg("n")){ int n = server.arg("n").toInt(); megaCometCfg.tailLen = (uint8_t)constrain(n, 10, 140); savePersist(); server.send(200,"text/plain; charset=utf-8","OK"); } else server.send(400,"text/plain; charset=utf-8","ERR"); }
void handleMegaGlitter(){ megaCometCfg.glitter = !megaCometCfg.glitter; savePersist(); server.send(200,"text/plain; charset=utf-8", String("OK: glitter=")+String(megaCometCfg.glitter)); }
// Clock schedule routes
void handleClockSchedToggle(){
  if(!server.hasArg("which")){ server.send(400,"text/plain; charset=utf-8","ERR"); return; }
  int which = server.arg("which").toInt();
  if(which==0) clockSchedWeek.enabled = !clockSchedWeek.enabled;
  else clockSchedWeekend.enabled = !clockSchedWeekend.enabled;
  savePersist();
  server.send(200,"text/plain; charset=utf-8","OK");
}
void handleClockSchedSet(){
  if(!server.hasArg("which")){ server.send(400,"text/plain; charset=utf-8","ERR"); return; }
  int which = server.arg("which").toInt();
  if(which<0||which>1){server.send(400,"text/plain","invalid schedule");return;}
  ClockScheduleCfg* sc = (which==0) ? &clockSchedWeek : &clockSchedWeekend;
  if(server.hasArg("enabled")) sc->enabled=server.arg("enabled")=="1";
  if(server.hasArg("dimH")) sc->dimH = (uint8_t)constrain(server.arg("dimH").toInt(),0,23);
  if(server.hasArg("dimM")) sc->dimM = (uint8_t)constrain(server.arg("dimM").toInt(),0,59);
  if(server.hasArg("pct"))  sc->dimPercent = (uint8_t)constrain(server.arg("pct").toInt(),1,100);
  if(server.hasArg("offH")) sc->offH = (uint8_t)constrain(server.arg("offH").toInt(),0,23);
  if(server.hasArg("offM")) sc->offM = (uint8_t)constrain(server.arg("offM").toInt(),0,59);
  if(server.hasArg("onH"))  sc->onH  = (uint8_t)constrain(server.arg("onH").toInt(),0,23);
  if(server.hasArg("onM"))  sc->onM  = (uint8_t)constrain(server.arg("onM").toInt(),0,59);
  savePersist();
  server.send(200,"text/plain; charset=utf-8","OK");
}
void handlePower(){
  if(!server.hasArg("on")){server.send(400,"text/plain","on required");return;}
  if(server.arg("on")=="1"){VegaRender::selectMode(mode,clockOn,lampOn);clockIntensity=clockIntensityDefault;brightness=effectIntensityDefault;if(lampOn)startEffect(currentEffectIndex);}
  else{lampOn=false;clockOn=false;anim.active=false;megaCometActive=false;previewLed=-1;hardOff();}
  configuredClockOn=clockOn;configuredLampOn=lampOn;
  savePersist();syncSinricPowerIfChanged();server.send(200,"text/plain","OK");
}
void handleAppearance(){
  if(server.hasArg("protect"))contrastProtection=server.arg("protect")=="1";
  if(server.hasArg("showSeconds"))showSecondsHand=server.arg("showSeconds")=="1";
  savePersist();server.send(200,"text/plain","OK");
}
void handleLanguage(){
  String value=server.arg("v");
  if(value!="en"&&value!="pl"){server.send(400,"text/plain","en/pl required");return;}
  uiPolish=value=="pl";savePersist();server.send(200,"text/plain","OK");
}
void handlePalette(){
  if(!server.hasArg("h")||!server.hasArg("m")||!server.hasArg("s")){server.send(400,"text/plain","colors required");return;}
  hourColor=parseHexColor(server.arg("h"));minuteColor=parseHexColor(server.arg("m"));secondColor=parseHexColor(server.arg("s"));
  savePersist();server.send(200,"text/plain","OK");
}
void handleLampSchedSet(){
  if(!server.hasArg("which")){server.send(400,"text/plain","which required");return;}
  int which=server.arg("which").toInt();if(which<0||which>1){server.send(400,"text/plain","invalid schedule");return;}
  Schedule2DimCfg &sc=which?schedWeekend:schedWeek;
  if(server.hasArg("enabled"))sc.enabled=server.arg("enabled")=="1";
  if(server.hasArg("dim1H"))sc.dim1H=constrain(server.arg("dim1H").toInt(),0,23);
  if(server.hasArg("dim1M"))sc.dim1M=constrain(server.arg("dim1M").toInt(),0,59);
  if(server.hasArg("pct1"))sc.dim1Percent=constrain(server.arg("pct1").toInt(),1,100);
  if(server.hasArg("dim2H"))sc.dim2H=constrain(server.arg("dim2H").toInt(),0,23);
  if(server.hasArg("dim2M"))sc.dim2M=constrain(server.arg("dim2M").toInt(),0,59);
  if(server.hasArg("pct2"))sc.dim2Percent=constrain(server.arg("pct2").toInt(),1,100);
  if(server.hasArg("offH"))sc.offH=constrain(server.arg("offH").toInt(),0,23);
  if(server.hasArg("offM"))sc.offM=constrain(server.arg("offM").toInt(),0,59);
  if(server.hasArg("onH"))sc.onH=constrain(server.arg("onH").toInt(),0,23);
  if(server.hasArg("onM"))sc.onM=constrain(server.arg("onM").toInt(),0,59);
  savePersist();server.send(200,"text/plain","OK");
}
// ======================== Render =====================================
void renderFrame(int h,int m,int s){
  unsigned long now=millis();
  if(now-lastFrameMs<FRAME_MS)return;
  lastFrameMs=now;
  if(previewLed>=0){
    if(now-previewStartedMs<700){fillAll(0);pixels.setPixelColor(previewLed,pixels.Color(160,160,160));pixels.show();return;}
    previewLed=-1;
  }
  const bool effects=VegaRender::showsEffects(mode,lampOn);
  if(effects){
    for(int i=0;i<NUMPIXELS;i++)pixels.setPixelColor(i,effectPixels[i]);
    ensureEffectRunning();updateEffect();
    for(int i=0;i<NUMPIXELS;i++)effectPixels[i]=pixels.getPixelColor(i);
    if(mode==1 && premiumBgOn){
      updatePremiumBackground();
      for(int i=0;i<NUMPIXELS;i++)pixels.setPixelColor(i,blendColor(pixels.getPixelColor(i),effectPixels[i],0.72f));
    }
    megaCometDraw();
  }else{fillAll(0);megaCometActive=false;}
  overlayTime(h,m,s); // Final composition puts time above every effect.
  pixels.show();
}

// ======================== OLED =======================================
void displayInfoOnOLED(int h,int m,int s,int wday){
  static unsigned long last=0;
  if(millis()-last<500)return;
  last=millis();display.clearDisplay();display.setTextSize(1);display.setCursor(0,0);
  display.print("VEGA 2.0");display.setCursor(86,0);display.print(currentOffsetSeconds?"BST":"GMT");
  display.drawLine(0,11,127,11,SSD1306_WHITE);
  display.setTextSize(3);display.setCursor(0,18);
  if(timeClient.isTimeSet()){display.print(two(h));display.print(":");display.print(two(m));}
  else display.print("--:--");
  display.setTextSize(1);display.setCursor(98,33);display.print(timeClient.isTimeSet()?two(s):"--");
  display.setCursor(0,46);
  if(mode==0)display.print(uiPolish?"Tylko godzina":"Time only");
  else if(mode==1)display.print(uiPolish?"Czas + efekty":"Time + ambience");
  else display.print(uiPolish?"Tylko efekty":"Effects only");
  display.setCursor(0,56);
  if(WiFi.status()==WL_CONNECTED)display.print(WiFi.localIP());
  else display.print(uiPolish?"Brak WiFi":"WiFi offline");
  display.display();
}

// ======================== SINRIC callbacks ============================
// UWAGA: callback jest na SinricProSwitch
bool onSinricPowerState(const String &deviceId, bool &state) {
  (void)deviceId;
  if(state) {
    // ON: włącz oba (żeby z Alexa/Sinric w ogóle było "coś widać")
    VegaRender::selectMode(mode,clockOn,lampOn);
    brightness=effectIntensityDefault;
    pixels.setBrightness(255);
    if((mode==1 || mode==2) && lampOn) startEffect(currentEffectIndex);
    clockIntensity = clockIntensityDefault;
  } else {
    // OFF: gaś wszystko
    lampOn = false;
    clockOn = false;
    anim.active = false;
    hardOff();
  }
  configuredClockOn=clockOn;configuredLampOn=lampOn;
  savePersist();
  syncSinricPowerIfChanged();
  return true;
}
void setupSinricPro() {
  // 1) Pobieramy urządzenie jako referencję (to jest poprawny wzorzec dla Sinric 4.x)
  SinricProSwitch& sw = SinricPro[SWITCH_ID_1];
  // 2) Trzymamy wskaźnik do bazowego typu (bez & na proxy)
  g_sinricDev = &sw;
  // 3) Callback
  sw.onPowerState(onSinricPowerState);
  SinricPro.onConnected([](){
    Serial.println("[SinricPro] Connected");
  });
  SinricPro.onDisconnected([](){
    Serial.println("[SinricPro] Disconnected");
  });
  SinricPro.begin(APP_KEY, APP_SECRET);
  // wymuś pierwszą synchronizację w appce
  g_lastSinricReported = !sinricPowerNow();
  syncSinricPowerIfChanged();
}
// ======================== Setup / Loop ================================
void setup(){
  Serial.begin(115200);
  randomSeed(micros());
  pixels.begin();
  pixels.clear();
  pixels.show();
  Wire.begin(SDA_PIN, SCL_PIN);
  display.begin(SSD1306_SWITCHCAPVCC, 0x3C);
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(SSD1306_WHITE);
  display.setCursor(0,0);
  display.println("VEGA ZEGAR");
  display.display();
  loadPersist();
  pixels.setBrightness(255);
  startEffect(currentEffectIndex);
  // ===================== WiFi =====================
  WiFi.mode(WIFI_STA);
  WiFi.persistent(false);
  WiFi.setAutoReconnect(true);
  WiFi.hostname(mdnsName);
  WiFi.begin(ssid, password);
  int retries=0;
  while(WiFi.status()!=WL_CONNECTED && retries<120){
    delay(250);
    retries++;
  }
  WiFi.setSleepMode(WIFI_NONE_SLEEP);
  // mDNS
  if(MDNS.begin(mdnsName)){
    MDNS.addService("http","tcp",80);
  }
  // OTA (Arduino IDE)
  ArduinoOTA.setPassword(OTApassword);
  ArduinoOTA.begin();
  // Web OTA (/update)
  httpUpdater.setup(&server, "/update", "admin", OTApassword);
  // WWW
  server.on("/", handleRoot);
  server.on("/power",handlePower);
  server.on("/appearance",handleAppearance);
  server.on("/language",handleLanguage);
  server.on("/palette",handlePalette);
  server.on("/lampSched/set",handleLampSchedSet);
  server.on("/state", handleState);
  server.on("/toggleLamp", handleToggleLamp);
  server.on("/toggleClock", handleToggleClock);
  server.on("/setMode", handleSetMode);
  server.on("/setBrightness", handleSetBrightness);
  server.on("/setClockInt", handleSetClockInt);
  server.on("/pbg/toggle", handlePbgToggle);
  server.on("/pbg/brightness", handlePbgBrightness);
  server.on("/setEffect", handleSetEffect);
  server.on("/setColor", handleSetColor);
  server.on("/calib/save", handleCalSave);
  server.on("/calib/preview", handleCalPreview);
  server.on("/mega/toggle", handleMegaToggle);
  server.on("/mega/test", handleMegaTest);
  server.on("/mega/dur", handleMegaDur);
  server.on("/mega/tail", handleMegaTail);
  server.on("/mega/glitter", handleMegaGlitter);
  server.on("/clockSched/toggle", handleClockSchedToggle);
  server.on("/clockSched/set", handleClockSchedSet);
  server.begin();
  delay(150);
  // SinricPro
  setupSinricPro();
  // NTP
  timeClient.begin();
  refreshUKOffset();
}
void loop(){
  server.handleClient();
  ArduinoOTA.handle();
  MDNS.update();
  // SinricPro musi chodzić często
  SinricPro.handle();
  timeClient.update();
  if(timeClient.isTimeSet())refreshUKOffset();
  flushPendingSave();
  int h = timeClient.getHours();
  int m = timeClient.getMinutes();
  int s = timeClient.getSeconds();
  static int lastMinute = -1;
  static bool lastPower = true;
  if(timeClient.isTimeSet() && m != lastMinute){
    refreshUKOffset();
    lastMinute = m;
    time_t loc = timeClient.getEpochTime();
    int wday = getWdayLocal(loc);
    const Schedule2DimCfg& scLamp = isWeekend(wday) ? schedWeekend : schedWeek;
    const ClockScheduleCfg& scClock = isWeekend(wday) ? clockSchedWeekend : clockSchedWeek;
    applySchedule2Dim(scLamp, h, m);
    applyClockSchedule(scClock, h, m);
    if(megaCometCfg.enabled && clockOn) megaCometTrigger();
    bool p = sinricPowerNow();
    if (p != lastPower) {
      lastPower = p;
      syncSinricPowerIfChanged();
    }
  }
  renderFrame(h,m,s);
  time_t loc = timeClient.getEpochTime();
  int wday = getWdayLocal(loc);
  displayInfoOnOLED(h,m,s,wday);
  delay(2);
}