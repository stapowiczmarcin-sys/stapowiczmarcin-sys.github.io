#pragma once
#include <ESP8266WiFi.h>
#include <time.h>

// Core SNTP runs asynchronously. Missing NTP responses cannot stall LED frames,
// web controls, SinricPro or OTA for a blocking UDP timeout.
class KoraTimeClient {
  int offsetSeconds=0;
  const char *serverName;
public:
  explicit KoraTimeClient(const char *server):serverName(server) {}
  void begin(){configTime(0,0,serverName,"time.cloudflare.com","time.google.com");}
  bool update() const {return isTimeSet();}
  bool isTimeSet() const {return time(nullptr)>=1609459200;}
  void setTimeOffset(int seconds){offsetSeconds=seconds;}
  unsigned long getEpochTime() const {
    const time_t epoch=time(nullptr);
    return epoch>0?(unsigned long)(epoch+offsetSeconds):0;
  }
  int getHours() const {return (getEpochTime()%86400UL)/3600;}
  int getMinutes() const {return (getEpochTime()%3600UL)/60;}
  int getSeconds() const {return getEpochTime()%60UL;}
};
