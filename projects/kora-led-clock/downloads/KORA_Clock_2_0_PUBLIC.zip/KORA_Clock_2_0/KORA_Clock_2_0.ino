// Open this sketch in Arduino IDE. Keep all headers in this folder.
#include "KoraFirmware.h"
