from pathlib import Path

folder=Path(__file__).resolve().parent
html=(folder/'WebPanel.html').read_text(encoding='utf-8')
if ')KORA_HTML"' in html:
    raise ValueError('HTML contains the reserved raw-string delimiter')
(folder/'WebUI.h').write_text(
    '#pragma once\n#include <Arduino.h>\nstatic const char KORA_WEB_UI[] PROGMEM = R"KORA_HTML('
    +html+')KORA_HTML";\n',encoding='utf-8')
print('WebUI.h updated from WebPanel.html')
