#pragma once
#include <stdint.h>

// Pure composition: effect history never contains clock pixels.
namespace KoraRender {
inline uint32_t scale(uint32_t c, unsigned b) {
  return ((((c >> 16) & 255) * b / 255) << 16) |
         ((((c >> 8) & 255) * b / 255) << 8) | ((c & 255) * b / 255);
}
inline unsigned peak(uint32_t c) {
  unsigned r=(c>>16)&255, g=(c>>8)&255, b=c&255;
  return r>g ? (r>b?r:b) : (g>b?g:b);
}
inline uint32_t maximum(uint32_t a, uint32_t b) {
  uint32_t result=0;
  for(unsigned shift=0;shift<24;shift+=8) {
    unsigned x=(a>>shift)&255, y=(b>>shift)&255;
    result|=(x>y?x:y)<<shift;
  }
  return result;
}
inline int wrap(int p,int count) { p%=count; return p<0?p+count:p; }
inline int distance(int a,int b,int count) {
  int d=a>b?a-b:b-a; return d<count-d?d:count-d;
}
inline bool showsClock(int mode,bool on,bool synced) { return mode!=2 && on && synced; }
inline bool showsEffects(int mode,bool on) { return mode!=0 && on; }
inline void selectMode(int mode,bool &clock,bool &effects) {
  clock=mode!=2; effects=mode!=0;
}
inline void compose(const uint32_t *ambient,uint32_t *out,int count,
                    int mode,bool clockOn,bool lampOn,bool synced,
                    unsigned effectBrightness,unsigned clockBrightness,
                    const int positions[3],const uint32_t colors[3],
                    bool protect,bool seconds) {
  const bool clock=showsClock(mode,clockOn,synced);
  const bool effects=showsEffects(mode,lampOn);
  const int hands=seconds?3:2;
  for(int i=0;i<count;i++) {
    uint32_t c=effects?scale(ambient[i],effectBrightness):0;
    if(clock && protect) {
      const unsigned cap=clockBrightness*45/100;
      const unsigned top=peak(c);
      if(top>cap && top) c=scale(c,cap*255/top);
      for(int hand=0;hand<hands;hand++) {
        int d=distance(i,positions[hand],count);
        if(d<=3) { c=0; break; }
        if(d==4) c=scale(c,70);
      }
    }
    out[i]=c;
  }
  if(!clock) return;
  // Short, distinct tails. All cores are painted last so tails cannot hide them.
  const int tails[3]={3,4,1};
  for(int hand=0;hand<hands;hand++) {
    uint32_t c=scale(colors[hand],clockBrightness);
    for(int t=1;t<=tails[hand];t++) {
      int p=wrap(positions[hand]-t,count);
      out[p]=maximum(out[p],scale(c,100*(tails[hand]+1-t)/(tails[hand]+1)));
    }
  }
  for(int hand=0;hand<hands;hand++) {
    uint32_t c=scale(colors[hand],clockBrightness);
    if(hand<2) {
      int p=wrap(positions[hand]+1,count);
      out[p]=maximum(out[p],scale(c,75));
    }
  }
  // Replace ambient at each core even when contrast protection is disabled.
  for(int hand=0;hand<hands;hand++) {
    uint32_t c=scale(colors[hand],clockBrightness);
    for(int other=0;other<hands;other++)
      if(positions[other]==positions[hand]) c=maximum(c,scale(colors[other],clockBrightness));
    out[positions[hand]]=c;
  }
}
}
