#pragma once
// Fill in your own values before uploading. This public file contains no personal credentials.
#define APP_KEY "YOUR_SINRIC_APP_KEY"
#define APP_SECRET "YOUR_SINRIC_APP_SECRET"
#define SWITCH_ID_1 "YOUR_SINRIC_SWITCH_DEVICE_ID"
const char* ssid = "YOUR_WIFI_SSID";
const char* password = "YOUR_WIFI_PASSWORD";
const char* OTApassword = "SET_YOUR_OWN_OTA_PASSWORD";
