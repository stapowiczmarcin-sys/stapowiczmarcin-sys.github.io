# KORA Design — nowa ramka i wykończenie

Zagłębiony panel 0,67 mm, ramka ekranu na poziomie zewnętrznego obrysu, dwustopniowe krawędzie okna, delikatny rowek wokół ramki, pierścień enkodera i trzy płytkie nacięcia na bokach. Minimalna grubość przedniej płaszczyzny pod rowkami około 2,05 mm. Wymiary montażowe pozostają takie jak w wersji biurkowej 15°.

Podgląd zawiera poglądowy ekran i gałkę, których nie ma w STL. Pliki gotowe do druku: KORA_front.stl, KORA_back_18650.stl oraz cztery kopie KORA_clip_print_4.stl.

Przód drukuj zewnętrzną płaszczyzną na stole; zagłębienie panelu tworzy krótki most 0,67 mm nad stołem. Przy słabym mostowaniu zastosuj podpory lokalne lub orientację na boku. Warstwa 0,12–0,16 mm lepiej odda drobne detale; 4 obrysy. Nie drukowano fizycznego prototypu.

# KORA — obudowa biurkowa 15°

Przedni panel odchylony do tyłu o 15° od pionu. Klinowy korpus ma integralny płaski spód. Pokrętło centralnie pod ekranem: x=41 mm, otwór Ø10 mm. Podgląd pokazuje poglądową gałkę, której nie ma w STL.

Gabaryty po złożeniu: około 82 × 81 × 135 mm (szerokość × głębokość × wysokość). Panel przedni ma długość 140 mm. Okno 45,8 × 60,8 mm dla ekranu 45 × 60 mm w pionie; płytka 56 × 89 mm.

Drukuj KORA_front.stl przednią płaszczyzną na stole — plik już jest tak ustawiony. Tylną pokrywę drukuj płaską stroną na stole, szynami do góry. Zalecane PLA/PETG, warstwa 0,2 mm, 4 obrysy, wypełnienie 20–30%. Podpory lokalne mogą być potrzebne pod słupkami. Cztery klipsy mocują krawędzie płytki: wydrukuj KORA_clip_print_4.stl cztery razy. Pokrywa: cztery wkręty do tworzywa Ø3 mm, długość 10 mm; klipsy: Ø2,5 mm, długość 6 mm. Sprawdź długość przed dokręcaniem.

Koszyk jednego ogniwa 18650 ma przewidzianą komorę 25 × 82 × 22 mm. Rozmiary koszyka i położenie aktywnego ekranu względem PCB nie zostały zmierzone; założony środek ekranu leży 6 mm powyżej środka PCB. Najpierw wydrukuj KORA_fit_test.stl i sprawdź dopasowanie do własnego modułu. Otwór boczny na przewód USB wymaga sprawdzenia względem położenia płytki ESP32.

Modele sprawdzono: zamknięte siatki, jedna bryła na plik, dodatnia objętość oraz brak nakładania pokrywy na korpus. Nie przeprowadzono fizycznego wydruku próbnego. Projekt_parametryczny.py i Wymiary.json umożliwiają zmianę wymiarów; potrzebne Python, numpy, manifold3d i trimesh.
