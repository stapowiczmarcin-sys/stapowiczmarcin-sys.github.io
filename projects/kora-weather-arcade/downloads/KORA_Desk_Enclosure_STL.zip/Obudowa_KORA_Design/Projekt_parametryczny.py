from pathlib import Path
import json
import numpy as np
import manifold3d as md
import trimesh
root=Path(__file__).resolve().parent
P=json.loads((root/'Wymiary.json').read_text(encoding='utf-8'))
def cube(w,h,d,x=0,y=0,z=0):return md.Manifold.cube((w,h,d)).translate((x,y,z))
def cyl(d,h,x,y,z=0):return md.Manifold.cylinder(h,d/2,circular_segments=72).translate((x,y,z))
def rr(w,h,r):return md.CrossSection.square((w-2*r,h-2*r)).offset(r,circular_segments=64).translate((r,r))
def rounded(w,h,r,d,x=0,y=0,z=0):return rr(w,h,r).extrude(d).translate((x,y,z))
def mesh(m):
 out=m.to_mesh64();return trimesh.Trimesh(vertices=np.asarray(out.vert_properties)[:,:3],faces=np.asarray(out.tri_verts),process=True)
W,H,D,F,T=P['case_w'],P['case_h'],P['body_depth'],P['front'],P['wall']
ox=(W-P['pcb_w'])/2;oy=P['pcb_bottom'];cy=oy+P['pcb_h']/2+P['screen_y_offset'];ww=P['screen_w']+2*P['screen_clearance'];wh=P['screen_h']+2*P['screen_clearance'];wx=(W-ww)/2;wy=cy-wh/2
window=rounded(ww,wh,.6,12,wx,wy,-1)
encoder=cyl(P['encoder_d'],10,P['encoder_x'],P['encoder_y'],-1)
back_button=cyl(P['back_button_d'],10,23,P['encoder_y'],-1)
# Angled front, horizontal floor and vertical removable rear cover.
angle=90+P['tilt_deg'];rear=P['desk_depth']
outer=rounded(W,H,P['corner'],110).rotate((angle,0,0))
inner=rounded(W-2*T,H-2*T,P['corner']-T,115,T,T,F).rotate((angle,0,0))
limit=cube(W+20,rear+20,220,-10,-rear,0)
outer=outer^limit
inner=inner^cube(W+20,250,220,-10,-150,T)
front=outer-inner
front=front-window.rotate((angle,0,0))-encoder.rotate((angle,0,0))-back_button.rotate((angle,0,0))
# Return to front-down printing coordinates while installing PCB seats.
front=front.rotate((-angle,0,0))
# Sculpted front: a continuous perimeter rim and recessed central panel.
# Screen bezel is left at the original front level, so PCB clearance is unchanged.
bezel=rounded(ww+9,wh+9,4.5,1.5,wx-4.5,wy-4.5,-.1)
recess=rounded(W-8,H-8,4,.35,4,4,-.01)+rounded(W-8.6,H-8.6,3.7,.68,4.3,4.3,-.01)
front=front-(recess-bezel)
# Two small steps soften the screen aperture without changing the through-hole.
front=front-rounded(ww+1.2,wh+1.2,1.2,.30,wx-.6,wy-.6,-.01)
front=front-rounded(ww+.6,wh+.6,.9,.58,wx-.3,wy-.3,-.01)
# Fine recessed line frames the screen bezel rather than adding a tall lip.
screen_line=rounded(ww+11.4,wh+11.4,5.7,.95,wx-5.7,wy-5.7,-.01)-rounded(ww+10,wh+10,5,.98,wx-5,wy-5,-.02)
front=front-screen_line
# Machined-looking circular accent surrounds the centered encoder.
ring=cyl(27,.95,P['encoder_x'],P['encoder_y'],-.01)-cyl(25.4,1.1,P['encoder_x'],P['encoder_y'],-.02)
front=front-ring
# Recessed button surround; no extra through openings.
button_rim=cyl(9.8,.92,23,P['encoder_y'],-.01)-cyl(8.4,1.1,23,P['encoder_y'],-.02)
front=front-button_rim
# Continuous seat under bare PCB edges, and lateral locating rim.
seat=rounded(P['pcb_w']+4.8,P['pcb_h']+4.8,1.0,P['pcb_seat_z']-F+.05,ox-2.4,oy-2.4,F-.05)-cube(P['pcb_w']-3.2,P['pcb_h']-3.2,10,ox+1.6,oy+1.6,F-.1)
rim=rounded(P['pcb_w']+4.8,P['pcb_h']+4.8,1.,1.2,ox-2.4,oy-2.4,P['pcb_seat_z'])-cube(P['pcb_w']+.8,P['pcb_h']+.8,4,ox-.4,oy-.4,P['pcb_seat_z']-.1)
front=front+seat+rim
# Four generic screw-down edge clips mount beside the PCB, avoiding its hole pattern.
clip_posts=[(9.,59.),(9.,115.),(W-9.,59.),(W-9.,115.)]
for x,y in clip_posts:front=front+cyl(7.,7.9-F+.05,x,y,F-.05)
for x,y in clip_posts:front=front-cyl(2.05,5,x,y,3.5)
# Rear pillars and lid are made in the vertical rear plane.
front=front.rotate((angle,0,0))
section=outer.rotate((-90,0,0)).slice(rear-.01)
inside=inner.rotate((-90,0,0)).slice(rear-.01)
rear_h=section.bounds()[3]
cover_posts=[(6.,8.),(W-6.,8.),(6.,rear_h-8.),(W-6.,rear_h-8.)]
for x,y in cover_posts:
 post=cyl(7.4,14,x,y,-14).rotate((90,0,0)).translate((0,-rear,0))
 front=front+post
for x,y in cover_posts:
 hole=cyl(2.7,13,x,y,-12).rotate((90,0,0)).translate((0,-rear,0))
 front=front-hole
front=front-cube(8,14,9,W-5,-66,25)
# Three shallow horizontal accents on each side, above the cable opening.
for z in [45,50,55]:
 for x in [-.1,W-.55]:
  front=front-cube(.65,28,1.1,x,-64,z)
# Work on the lid outside-down; mirror its vertical outline for assembly.
section=section.mirror((0,1)).translate((0,rear_h))
inside=inside.mirror((0,1)).translate((0,rear_h))
cover_posts=[(x,rear_h-y) for x,y in cover_posts]
lid=section.extrude(P['lid'])
lip=(inside.offset(-P['lid_fit_gap'])-inside.offset(-P['lid_fit_gap']-1.5)).extrude(2.2).translate((0,0,P['lid']))
for x,y in cover_posts:lip=lip-cyl(9.,5,x,y,P['lid']-.1)
lid=lid+lip
for x,y in cover_posts:lid=lid-cyl(3.4,10,x,y,-1)-cyl(6.2,1.4,x,y,-.1)
# Internal compartment holds a spring/contact 18650 holder, not a loose cell.
bx,by,bw,bl,bt=9.,14.,P['battery_bay_w'],P['battery_bay_l'],2.
bz=P['lid'];bh=P['battery_bay_depth']
for rail in [cube(bt,bl+2*bt,bh,bx-bt,by-bt,bz),cube(bt,bl+2*bt,bh,bx+bw,by-bt,bz),cube(bw,bt,bh,bx,by-bt,bz),cube(bw,bt,bh,bx,by+bl,bz)]:lid=lid+rail
# Cable exit at upper battery end and strap slots through both side rails.
lid=lid-cube(8,6,8,bx+8,by+bl-1,bz+bh-8)
for y in [by+22,by+60]:
 for x in [bx-bt-1,bx+bw-1]:lid=lid-cube(5,7,3.2,x,y,bz+10)
# Two low cable-tie saddles for controller/charging board in remaining space.
for x,y in [(49,26),(49,64)]:
 bridge=cube(18,8,5,x,y,bz)-cube(14,9,2.3,x+2,y-.5,bz+1)
 lid=lid+bridge
# Ventilation only above the battery bay.
for y in [103,109,115]:lid=lid-rounded(22,2,1,6,45,y,-1)
# Universal edge clip, hole is slotted so PCB thickness can be accommodated with thin tape.
clip=rounded(12,7,1.5,2.4)-rounded(4.2,2.9,1.4,6,1.1,2.05,-1)
# Cheap first-print panel for checking screen, encoder, and PCB pocket alignment.
fit=rounded(W,H,P['corner'],1.6)-window-encoder-back_button
# Locating outlines as 0.8 mm ridges, edges leave the visible cutout clear.
fit=fit+((rounded(P['pcb_w']+4.8,P['pcb_h']+4.8,1.,.8,ox-2.4,oy-2.4,1.6)-cube(P['pcb_w']+.8,P['pcb_h']+.8,3,ox-.4,oy-.4,1.5)))
assembled_front=front
front=front.rotate((-angle,0,0))
report={}
for name,obj in [('KORA_front',front),('KORA_back_18650',lid),('KORA_clip_print_4',clip),('KORA_fit_test',fit)]:
 m=mesh(obj);assert m.is_watertight and m.is_volume and len(m.split())==1,(name,m.is_watertight,len(m.split()))
 m.export(root/(name+'.stl'));report[name]={'watertight':bool(m.is_watertight),'components':len(m.split()),'size_mm':m.extents.tolist(),'volume_cm3':round(m.volume/1000,2),'triangles':len(m.faces)};print(name,report[name])
# Place both parts in their actual desktop positions.
assembled_back=lid.rotate((-90,0,0)).translate((0,-rear-P['lid'],rear_h))
inter=assembled_front^assembled_back
assert abs(inter.volume())<.05,inter.volume()
report['closed_shell_overlap_mm3']=round(abs(inter.volume()),6)
report['screen_aperture_mm']=[ww,wh];report['encoder_diameter_mm']=P['encoder_d'];report['battery_bay_mm']=[bw,bl,bh]
report['front_tilt_from_vertical_deg']=P['tilt_deg'];report['encoder_center_x_mm']=P['encoder_x']
report['recess_depth_mm']=.67;report['minimum_front_panel_mm']=F-.94
report['desktop_size_mm']=mesh(assembled_front+assembled_back).extents.tolist()
(root/'Kontrola_modelu.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
if __name__=='__main__':
 mesh(assembled_front).export(root/'KORA_assembly_front_preview.ply')
 mesh(assembled_back).export(root/'KORA_assembly_back_preview.ply')

