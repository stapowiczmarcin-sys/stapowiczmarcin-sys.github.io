#pragma once
void softCloud(int cx,int cy,int scale,uint8_t opacity){
 int rx=scale,ry=scale/3;
 for(int y=max(g.top,cy-ry*2);y<min(g.top+16,cy+ry+1);y++)for(int x=cx-rx;x<=cx+rx;x++){
  float q=float((x-cx)*(x-cx))/(rx*rx)+float((y-cy)*(y-cy))/(ry*ry);
  float q2=float((x-cx+rx/3)*(x-cx+rx/3))/(rx*rx*.30f)+float((y-cy+ry/2)*(y-cy+ry/2))/(ry*ry*1.3f);
  float edge=min(q,q2);if(edge<1.f)ink(x,y,WHITE,uint8_t(opacity*min(1.f,(1.f-edge)*5.f)));
 }
}
void cityMotion(uint32_t now){
 // Only the sky moves: restore the photograph each frame to erase trails.
 for(int k=0;k<3;k++){int x=int((now/180+k*93)%330)-45;softCloud(x,9+k*5,24+k*3,55);}
 if(country==0)for(int k=0;k<5;k++){
  int x=int((now/34+k*51)%300)-30,y=24+(k*7)%22+int(sinf(now*.0017f+k)*3);
  int wing=2+int(sinf(now*.014f+k*1.5f)*2);
  g.drawLine(x-4,y-wing,x,y,0x0000);g.drawLine(x,y,x+4,y-wing,0x0000);
 }
}
const Sprite& animatedSymbol(int code,bool day){
 if(code==0)return day?sp_sun:sp_moon;
 if(code<=2)return day?sp_part:sp_cloud;if(code==3)return sp_cloud;
 if(code==45||code==48)return sp_fog;if(code>=95)return sp_storm;
 if((code>=71&&code<=77)||(code>=85&&code<=86))return sp_snow;return sp_rain;
}
void spriteShadow(const Sprite& sp,int x,int y,int size){
 int h=size*sp.h/sp.w;
 for(int yy=max(0,g.top-y);yy<min(h,g.top+16-y);yy++)for(int xx=0;xx<size;xx++){
  int i=(yy*sp.h/h)*sp.w+xx*sp.w/size;
  ink(x+xx,y+yy,0x0002,pgm_read_byte(sp.alpha+i)*120/255);
 }
}
void weatherMotion(int x,int y,int size,int code,bool day,uint32_t now){
 float phase=now*.001f;
 bool snow=(code>=71&&code<=77)||(code>=85&&code<=86);
 bool rain=(code>=51&&code<=67)||(code>=80&&code<=82)||code>=95;
 if(code==0&&day){
  int cx=x+size/2,cy=y+size/2;
  for(int r=size/2+4;r>size/2-4;r--){uint8_t a=12+int(8*(1+sinf(phase*1.4f)));for(int yy=max(g.top,cy-r);yy<min(g.top+16,cy+r+1);yy++)for(int xx=cx-r;xx<=cx+r;xx++){int q=(xx-cx)*(xx-cx)+(yy-cy)*(yy-cy);if(abs(q-r*r)<r)ink(xx,yy,GOLD,a);}}
  for(int i=0;i<10;i++){float a=i*PI/5+phase*.09f;int r0=40,r1=46+int(2*sinf(phase*2+i));g.drawLine(cx+cosf(a)*r0,cy+sinf(a)*r0,cx+cosf(a)*r1,cy+sinf(a)*r1,GOLD);}
 }
 int dx=(code>0&&code<=48)?int(sinf(phase*.26f)*5):0;
 int dy=int(sinf(phase*.8f)*1.5f);spriteShadow(animatedSymbol(code,day),x+dx+5,y+dy+7,size);sprite(animatedSymbol(code,day),x+dx,y+dy,size);
 if(rain||snow){
  for(int k=0;k<12;k++){
   int xx=x+12+(k*19)%(size-24), yy=y+size/2+int((now/(snow?65:18)+k*11)%(size/2-5));
   if(snow){xx+=int(sinf(phase*.9f+k)*4);g.drawFastHLine(xx-2,yy,5,WHITE);g.drawFastVLine(xx,yy-2,5,WHITE);g.drawPixel(xx-1,yy-1,CYAN);}
   else {g.drawLine(xx,yy,xx-2,yy+5,CYAN);g.drawPixel(xx,yy,WHITE);}
  }
 }
 if(code>=95&&(now/160)%24==0){g.drawLine(x+53,y+50,x+46,y+65,GOLD);g.drawLine(x+46,y+65,x+56,y+62,GOLD);g.drawLine(x+56,y+62,x+48,y+78,GOLD);}
}
void minuteProgress(uint32_t){
 time_t stamp=sceneUtc;struct tm tm;bool synced=stamp>1700000000&&localtime_r(&stamp,&tm);
 char s[16];if(synced)snprintf(s,sizeof(s),"%02d s",tm.tm_sec);else strcpy(s,"-- s");
 heavyType(s,120,233,f_value,CYAN,1);type(tr("SEKUNDY","SECONDS"),148,230,f_micro,WHITE);
 g.fillRoundRect(28,246,184,6,3,0x4208);
 if(synced){int w=184*tm.tm_sec/59; if(w)g.fillRoundRect(28,246,w,6,3,CYAN);}
}
