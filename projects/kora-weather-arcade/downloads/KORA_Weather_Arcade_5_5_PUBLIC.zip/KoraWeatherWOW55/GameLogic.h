#pragma once
#include <stdint.h>
#include <math.h>

// No display or Arduino dependency: input and game rules can be tested on host.
enum ClickAction { CLICK_NONE, CLICK_SINGLE, CLICK_DOUBLE };
struct Clicks {
  bool raw=false,stable=false,pending=false,second=false,suppressed=false;
  uint32_t changedAt=0,releasedAt=0;
  static constexpr uint32_t WINDOW=330,DEBOUNCE=22;
  void cancel() { pending=false;second=false;suppressed=true; }
  ClickAction poll(bool down,uint32_t now,bool immediate=false) {
    if(down!=raw) { raw=down;changedAt=now; }
    ClickAction action=CLICK_NONE;
    if(pending&&!second&&now-releasedAt>WINDOW&&!(raw&&changedAt-releasedAt<=WINDOW)) {
      pending=false;action=CLICK_SINGLE;
    }
    if(now-changedAt>=DEBOUNCE&&raw!=stable) {
      stable=raw;
      if(suppressed) { if(!stable)suppressed=false;return CLICK_NONE; }
      if(stable) {
        if(pending&&changedAt-releasedAt<=WINDOW) { pending=false;second=true; }
      } else if(immediate) {
        pending=false;second=false;return CLICK_SINGLE;
      } else if(second) {
        second=false;pending=false;return CLICK_DOUBLE;
      } else { pending=true;releasedAt=now; }
    }
    if(suppressed) { if(!raw&&!stable)suppressed=false;return CLICK_NONE; }
    // A second press owns the gesture until its release. It never starts a spin.
    return action;
  }
};

struct Cell { uint8_t x,y; };
struct SnakeGame {
  static constexpr int W=20,H=22,CAP=W*H;
  Cell body[CAP],food;
  int length=4,dir=0,score=0;
  int turns[2]={0,0},turnCount=0;
  bool paused=true,over=false,won=false;
  uint32_t tickAt=0;
  uint32_t (*randomFn)(uint32_t)=nullptr;
  bool occupies(int x,int y,int count) const {
    for(int i=0;i<count;i++)if(body[i].x==x&&body[i].y==y)return true;
    return false;
  }
  void spawnFood() {
    int free=CAP-length;
    if(!free) { won=true;over=true;return; }
    int target=randomFn?int(randomFn(free)):0;
    for(int y=0;y<H;y++)for(int x=0;x<W;x++)
      if(!occupies(x,y,length)&&target--==0) {food={(uint8_t)x,(uint8_t)y};return;}
  }
  void reset(uint32_t now,uint32_t (*rng)(uint32_t)) {
    randomFn=rng;length=4;dir=0;score=0;turnCount=0;paused=true;over=won=false;tickAt=now;
    for(int i=0;i<length;i++)body[i]={(uint8_t)(10-i),11};
    spawnFood();
  }
  void turn(int sign) {
    if(paused||over||!sign||turnCount>=2)return;
    turns[turnCount++]=sign>0?1:-1;
  }
  void click(uint32_t now) {
    if(over)reset(now,randomFn);
    paused=!paused;tickAt=now;turnCount=0;
  }
  uint32_t interval() const { int ms=155-score*3;return ms<75?75:ms; }
  bool update(uint32_t now) {
    if(paused||over||now-tickAt<interval())return false;
    tickAt=now;
    if(turnCount) { dir=(dir+turns[0]+4)%4;turns[0]=turns[1];--turnCount; }
    const int dx[4]={1,0,-1,0},dy[4]={0,1,0,-1};
    int x=body[0].x+dx[dir],y=body[0].y+dy[dir];
    bool eat=x==food.x&&y==food.y;
    // The tail vacates its cell unless food is eaten.
    if(x<0||x>=W||y<0||y>=H||occupies(x,y,length-(eat?0:1))) {over=true;return true;}
    int nextLength=length+(eat?1:0);
    for(int i=nextLength-1;i>0;i--)body[i]=body[i-1];
    body[0]={(uint8_t)x,(uint8_t)y};length=nextLength;
    if(eat){score++;spawnFood();}
    return eat;
  }
};

struct BreakoutGame {
  bool bricks[4][9];
  bool paused=true,ready=true,over=false,won=false;
  int score=0,lives=3,remaining=36;
  float paddle=120,bx=120,by=272,vx=75,vy=-120;
  float trailX[6],trailY[6];
  uint32_t at=0,trailAt=0;
  void dock() {
    bx=paddle;by=272;vx=75;vy=-120;ready=true;
    for(int i=0;i<6;i++){trailX[i]=bx;trailY[i]=by;}
  }
  void reset(uint32_t now) {
    paused=true;over=won=false;score=0;lives=3;remaining=36;paddle=120;at=trailAt=now;
    for(int r=0;r<4;r++)for(int c=0;c<9;c++)bricks[r][c]=true;
    dock();
  }
  void move(int steps) {
    paddle+=steps*9;
    if(paddle<36)paddle=36;if(paddle>204)paddle=204;
    if(ready)bx=paddle;
  }
  void click(uint32_t now) {
    if(over)reset(now);
    if(ready){ready=false;paused=false;}
    else paused=!paused;
    at=now;
  }
  bool update(uint32_t now) {
    uint32_t elapsed=now-at;at=now;
    if(paused||ready||over)return false;
    if(elapsed>80)elapsed=80; // Pause-safe; no huge jumps after a slow frame.
    if(!elapsed)return false;
    if(now-trailAt>=12) {
      trailAt=now;
      for(int i=5;i>0;i--){trailX[i]=trailX[i-1];trailY[i]=trailY[i-1];}
      trailX[0]=bx;trailY[0]=by;
    }
    bool changed=false;
    int steps=(elapsed+4)/5;float dt=elapsed*.001f/steps;
    for(int step=0;step<steps;step++) {
      float oldX=bx,oldY=by;bx+=vx*dt;by+=vy*dt;
      if(bx<23){bx=23;vx=fabsf(vx);}if(bx>217){bx=217;vx=-fabsf(vx);}
      if(by<53){by=53;vy=fabsf(vy);}
      if(vy>0&&oldY+3<=278&&by+3>=278&&bx+3>=paddle-24&&bx-3<=paddle+24) {
        float offset=(bx-paddle)/24; if(offset<-1)offset=-1;if(offset>1)offset=1;
        float speed=145+score*.18f;if(speed>220)speed=220;
        vx=offset*speed*.82f;vy=-sqrtf(speed*speed-vx*vx);by=275;
      }
      bool hit=false;
      for(int r=0;r<4&&!hit;r++)for(int c=0;c<9;c++) {
        if(!bricks[r][c])continue;
        float x=23+c*22,y=62+r*18;
        if(bx+3>x&&bx-3<x+18&&by+3>y&&by-3<y+12) {
          bricks[r][c]=false;remaining--;score+=10;changed=true;hit=true;
          if(oldY+3<=y) {by=y-3;vy=-fabsf(vy);}
          else if(oldY-3>=y+12){by=y+15;vy=fabsf(vy);}
          else if(oldX<x){bx=x-3;vx=-fabsf(vx);}
          else {bx=x+21;vx=fabsf(vx);}
          break;
        }
      }
      if(!remaining){won=over=true;return true;}
      if(by>300){lives--;if(!lives)over=true;else dock();return true;}
    }
    return changed;
  }
};
