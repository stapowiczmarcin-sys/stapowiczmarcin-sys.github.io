#pragma once
// Pac-Man-style maze: encoder chooses relative direction, button pauses.
struct PacmanGame {
 static constexpr int W=15,H=17;
 bool pellets[H][W],paused=true,over=false,won=false;
 int x=1,y=1,dir=0,wanted=0,score=0,lives=3,left=0,power=0;
 Cell ghosts[3];uint32_t at=0;uint32_t (*rng)(uint32_t)=nullptr;
 static constexpr const char* maze[H]={
  "###############",
  "#         #   #",
  "#########   # #",
  "#         # # #",
  "# ### # # # # #",
  "# #       #   #",
  "# # #### ## # #",
  "# #       #   #",
  "# # ##  # # ###",
  "#       # #   #",
  "# #### ## # # #",
  "#       # #   #",
  "# ### ### # ###",
  "#   #   # #   #",
  "### #   # # # #",
  "#             #",
  "###############"};
 bool wall(int xx,int yy)const{
  return xx<0||yy<0||xx>=W||yy>=H||maze[yy][xx]=='#';
 }
 void actors(){x=1;y=1;dir=wanted=0;ghosts[0]={13,15};ghosts[1]={13,1};ghosts[2]={1,15};power=0;}
 void reset(uint32_t now,uint32_t(*r)(uint32_t)){
  rng=r;score=0;lives=3;left=0;paused=true;over=won=false;at=now;actors();
  for(int yy=0;yy<H;yy++)for(int xx=0;xx<W;xx++){pellets[yy][xx]=!wall(xx,yy);if(pellets[yy][xx])left++;}
 }
 void turn(int sign){wanted=(wanted+sign+4)%4;}
 void click(uint32_t now){if(over)reset(now,rng);paused=!paused;at=now;}
 void collision(){for(int i=0;i<3;i++)if(x==ghosts[i].x&&y==ghosts[i].y){
  if(power){score+=100;ghosts[i]={13,15};}
  else {if(--lives==0)over=true;else {actors();paused=true;}return;}
 }}
 bool update(uint32_t now){
  if(paused||over||now-at<160)return false;at=now;
  const int dx[]={1,0,-1,0},dy[]={0,1,0,-1};
  if(!wall(x+dx[wanted],y+dy[wanted]))dir=wanted;
  if(!wall(x+dx[dir],y+dy[dir])){x+=dx[dir];y+=dy[dir];}
  if(power)power--;
  if(pellets[y][x]){pellets[y][x]=false;left--;score+=10;if((x==1||x==13)&&(y==1||y==15))power=50;}
  if(!left){won=over=true;return true;}collision();if(over||paused)return true;
  for(int i=0;i<3;i++){
   int best=999,chosen=-1;
   for(int d=0;d<4;d++){int xx=ghosts[i].x+dx[d],yy=ghosts[i].y+dy[d];if(wall(xx,yy))continue;
    int dist=abs(xx-x)+abs(yy-y);int rank=(power?40-dist:dist)*4+int(rng?rng(5):0);
    if(rank<best){best=rank;chosen=d;}}
   if(chosen>=0){ghosts[i].x+=dx[chosen];ghosts[i].y+=dy[chosen];}
  }collision();return true;
 }
};
struct InvadersGame {
 bool alive[4][8],paused=true,over=false,won=false;
 int ship=120,score=0,lives=3,remaining=32,level=1,dir=1,ox=24,oy=65;
 int shotX=0,shotY=-1,enemyX=0,enemyY=-1;
 uint32_t at=0,marchAt=0,fireAt=0;
 void wave(){for(int r=0;r<4;r++)for(int c=0;c<8;c++)alive[r][c]=true;remaining=32;ox=24;oy=65;dir=1;}
 void reset(uint32_t now){score=0;lives=3;level=1;ship=120;paused=true;over=won=false;shotY=enemyY=-1;at=marchAt=fireAt=now;wave();}
 void move(int steps){ship+=steps*7;if(ship<20)ship=20;if(ship>220)ship=220;}
 void click(uint32_t now){if(over){reset(now);paused=false;}else paused=!paused;at=marchAt=now;}
 bool update(uint32_t now,uint32_t(*rng)(uint32_t)){
  if(paused||over||now-at<30)return false;at=now;
  // Automatic fire keeps single-encoder control responsive.
  if(shotY<0&&now-fireAt>350){shotX=ship;shotY=276;fireAt=now;}
  if(shotY>=0){shotY-=7;for(int r=0;r<4;r++)for(int c=0;c<8;c++)if(alive[r][c]){
   int xx=ox+c*23,yy=oy+r*22;
   if(shotY>=yy-6&&shotY<=yy+17&&abs(shotX-xx)<12){alive[r][c]=false;remaining--;score+=(4-r)*10;shotY=-1;}
  }}
  if(enemyY<0&&rng(18)==0){int start=rng(8);for(int j=0;j<8;j++){int c=(start+j)%8;bool found=false;for(int r=3;r>=0;r--)if(alive[r][c]){enemyX=ox+c*23;enemyY=oy+r*22+12;found=true;break;}if(found)break;}}
  if(enemyY>=0){enemyY+=4;if(enemyY>=272&&enemyY<=289&&abs(enemyX-ship)<13){enemyY=-1;if(--lives==0)over=true;}else if(enemyY>301)enemyY=-1;}
  int period=420-(32-remaining)*8-(level-1)*35;if(period<100)period=100;
  if(now-marchAt>=uint32_t(period)){marchAt=now;int lo=999,hi=-999;for(int r=0;r<4;r++)for(int c=0;c<8;c++)if(alive[r][c]){lo=min(lo,ox+c*23);hi=max(hi,ox+c*23);if(oy+r*22+16>=272)over=true;}
   if((dir>0&&hi>=215)||(dir<0&&lo<=25)){dir=-dir;oy+=10;}else ox+=dir*5;
  }
  if(!remaining){if(level==3)won=over=true;else {level++;wave();shotY=enemyY=-1;}}
  return true;
 }
};
