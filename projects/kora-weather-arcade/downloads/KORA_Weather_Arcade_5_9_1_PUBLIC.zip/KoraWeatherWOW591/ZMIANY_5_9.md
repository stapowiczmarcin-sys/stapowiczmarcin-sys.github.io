EN: Birds in all four cities; main weather icon 100px; full-height condensed temperature digits; added Neon Blocks with move/rotate/drop/pause, next piece and landing ghost.

PL: Ptaki nad każdym z czterech miast; główna ikona pogody 100px; wysokie, węższe cyfry temperatury; nowa gra Neon Blocks z przesuwaniem/obrotem/zrzutem/pauzą, następnym klockiem i obrysem lądowania.
