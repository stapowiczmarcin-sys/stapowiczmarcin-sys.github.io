EN: Larger 64px forecast symbols, fixed bold maximum/minimum digits, 84px home clock and temperature, 90px standalone clock. Same temperature size for 14 / -20 / 100; black outlines retained. Sun rays scale with icon size to avoid digits.

PL: Większe symbole prognozy 64px, stałe pogrubione cyfry temperatur max/min, godzina i temperatura na stronie pogody 84px, osobny zegar 90px. Ten sam rozmiar temperatury 14 / -20 / 100; zachowane czarne obwódki. Promienie słońca dopasowane do ikony, bez wchodzenia na cyfry.
