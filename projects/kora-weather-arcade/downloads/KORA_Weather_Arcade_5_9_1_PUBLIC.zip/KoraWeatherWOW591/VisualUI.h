#pragma once
// All sprites/backgrounds/fonts live in flash. Only the 240 x 16 strip is RAM.
// Alpha blending is local to the strip; no full-screen redraw-to-black.

uint16_t blend565(uint16_t bg,uint16_t fg,uint8_t a) {
  if(a==255) return fg;
  if(!a) return bg;
  int r=(((bg>>11)&31)*(255-a)+((fg>>11)&31)*a+127)/255;
  int gg=(((bg>>5)&63)*(255-a)+((fg>>5)&63)*a+127)/255;
  int b=((bg&31)*(255-a)+(fg&31)*a+127)/255;
  return (r<<11)|(gg<<5)|b;
}
void ink(int x,int y,uint16_t color,uint8_t alpha=255) {
  if(x<clipLeft||x>=clipRight) return;
  x+=g.shift; y-=g.top;
  if(x<0||x>=240||y<0||y>=16||!alpha) return;
  uint16_t* p=g.pixels.getBuffer()+y*240+x;
  *p=blend565(*p,color,alpha);
}
int textWidth(const char* str,const SmoothFont& f) {
  int width=0;
  for(;*str;str++) if(*str>=f.first&&*str<=f.last) width+=f.glyphs[*str-f.first].advance;
  return width;
}
void type(const char* str,int x,int baseline,const SmoothFont& f,uint16_t color=WHITE,int align=0) {
  int width=textWidth(str,f);
  if(align==1) x-=width/2;
  if(align==2) x-=width;
  for(;*str;str++) {
    if(*str<f.first||*str>f.last) continue;
    const Glyph& a=f.glyphs[*str-f.first];
    if(x+a.ox+a.w<=clipLeft||x+a.ox>=clipRight){x+=a.advance;continue;}
    int yy=baseline+a.oy;
    for(int y=max(0,g.top-yy);y<min(int(a.h),g.top+16-yy);y++)
      for(int xx=0;xx<a.w;xx++) ink(x+a.ox+xx,yy+y,color,pgm_read_byte(f.bitmap+a.offset+y*a.w+xx));
    x+=a.advance;
  }
}
// Dilate the glyph mask once: bold digits without repeated alpha overdraw.
void heavyType(const char* str,int x,int baseline,const SmoothFont& f,uint16_t color=WHITE,int align=0){
 int width=textWidth(str,f)+2;
 if(align==1)x-=width/2;if(align==2)x-=width;
 for(;*str;str++){
  if(*str<f.first||*str>f.last)continue;
  const Glyph& a=f.glyphs[*str-f.first];int yy=baseline+a.oy;
  for(int y=max(0,g.top-yy);y<min(int(a.h),g.top+16-yy);y++)for(int xx=-1;xx<int(a.w)+1;xx++){
   uint8_t alpha=0;
   for(int d=-1;d<=1;d++){int sx=xx+d;if(sx>=0&&sx<a.w){uint8_t v=pgm_read_byte(f.bitmap+a.offset+y*a.w+sx);if(v>alpha)alpha=v;}}
   ink(x+a.ox+xx,yy+y,color,alpha);
  }
  x+=a.advance;
 }
}
// Draw the black outline and white fill from the same glyph mask.
// Include rows above/below each strip so outlines never break at strip seams.
void outlinedType(const char* str,int x,int baseline,const SmoothFont& f,uint16_t color=WHITE,int align=0,bool bold=false,int radius=2){
 int weight=bold?2:0,vertical=bold?1:0,width=textWidth(str,f)+2*weight;
 if(align==1)x-=width/2;if(align==2)x-=width;
 for(;*str;str++){
  if(*str<f.first||*str>f.last)continue;
  const Glyph& a=f.glyphs[*str-f.first];int yy=baseline+a.oy;
  if(x+a.ox+a.w+radius+weight<=clipLeft||x+a.ox-radius-weight>=clipRight){x+=a.advance;continue;}
  for(int y=max(-radius-vertical,g.top-yy);y<min(int(a.h)+radius+vertical,g.top+16-yy);y++)
   for(int xx=-radius-weight;xx<int(a.w)+radius+weight;xx++){
    uint8_t fill=0,edge=0;
    for(int dy=-radius-vertical;dy<=radius+vertical;dy++){
     int sy=y+dy;if(sy<0||sy>=a.h)continue;
     int span=radius-max(0,abs(dy)-vertical)+weight;
     for(int dx=-span;dx<=span;dx++){
      int sx=xx+dx;if(sx<0||sx>=a.w)continue;
      uint8_t v=pgm_read_byte(f.bitmap+a.offset+sy*a.w+sx);
      if(v>edge)edge=v;
      if(abs(dy)<=vertical&&abs(dx)<=weight&&v>fill)fill=v;
     }
    }
    if(edge)ink(x+a.ox+xx,yy+y,0x0000,edge);
    if(fill)ink(x+a.ox+xx,yy+y,color,fill);
   }
  x+=a.advance;
 }
}
void pressureIcon(int x,int y){
 // Smooth semicircular barometer, five ticks and a filled needle.
 for(int r=17;r<=19;r++)for(int i=0;i<=60;i++){
  float a=PI+i*PI/60;g.drawPixel(x+int(cosf(a)*r),y+int(sinf(a)*r),CYAN);
 }
 for(int i=0;i<5;i++){float a=PI+i*PI/4;g.drawLine(x+int(cosf(a)*12),y+int(sinf(a)*12),x+int(cosf(a)*15),y+int(sinf(a)*15),WHITE);}
 g.fillTriangle(x-2,y,x+2,y,x+9,y-11,WHITE);g.fillCircle(x,y,3,WHITE);
 g.drawFastHLine(x-19,y+5,39,CYAN);
}
void windIcon(int x,int y){
 g.drawRoundRect(x-17,y-11,34,8,4,CYAN);g.fillRect(x-18,y-3,35,4,0);
 g.drawFastHLine(x-19,y,28,CYAN);g.drawCircle(x+10,y+4,4,CYAN);g.fillRect(x+5,y+1,5,7,0);
 g.drawFastHLine(x-12,y+10,24,CYAN);
}
void humidityIcon(int x,int y){
 g.fillTriangle(x,y-17,x-10,y,x+10,y,CYAN);g.fillCircle(x,y,10,CYAN);
 g.drawLine(x-5,y-1,x-5,y+3,WHITE);g.drawPixel(x-4,y+4,WHITE);
}
void sprite(const Sprite& sp,int x,int y,int size=0,uint8_t opacity=255) {
  int w=size?size:sp.w,h=size?size*sp.h/sp.w:sp.h;
  for(int yy=max(0,g.top-y);yy<min(h,g.top+16-y);yy++) {
    int sy=yy*sp.h/h;
    for(int xx=0;xx<w;xx++) {
      int i=sy*sp.w+xx*sp.w/w;
      uint8_t a=pgm_read_byte(sp.alpha+i);
      if(a) ink(x+xx,y+yy,pgm_read_word(sp.rgb+i),uint16_t(a)*opacity/255);
    }
  }
}
uint16_t dim565(uint16_t c,int light){return ((((c>>11)&31)*light/255)<<11)|((((c>>5)&63)*light/255)<<5)|((c&31)*light/255);}
void photo(const Photo& p,int x,int y){
 for(int yy=max(y,g.top);yy<min(min(y+int(p.h),160),g.top+16);yy++)
  for(int xx=max(0,x);xx<min(240,x+int(p.w));xx++)
   g.drawPixel(xx,yy,pgm_read_word(p.pixels+((p.h>160?(yy-y)*int(p.h)/160:yy-y))*p.w+xx-x));
}
void base(){
 if(hasCityBanner(mode)){
  g.fillRect(0,g.top,240,16,0x0000);
  photo(*countries[country].photo,0,0);
  for(int y=g.top;y<g.top+16;y++)for(int x=0;x<240;x++)if(y<160)ink(x,y,0x0006,18);
 }
 else g.fillRect(0,g.top,240,16,0x0000);
}
void glass(int x,int y,int w,int h,uint8_t alpha){
 for(int yy=max(y,g.top);yy<min(y+h,g.top+16);yy++)for(int xx=x;xx<x+w;xx++)ink(xx,yy,0x0000,alpha);
}
void billboardType(const char* text,int x,int y,const SmoothFont& f,uint16_t color=WHITE,int align=0){
 outlinedType(text,x,y,f,color,align,false,1);
}
#include "MotionUI.h"
void cityBanner(uint32_t now){
 cityMotion(now);glass(0,0,240,56,95);flyingBirds(now);
 billboardType(countries[country].city,12,25,f_medium,WHITE);
 billboardType(language?"EN":"PL",202,24,f_micro,CYAN,2);
 if(WiFi.status()==WL_CONNECTED){
  g.fillCircle(226,25,1,CYAN);
  for(int y=12;y<=21;y++)for(int x=216;x<=236;x++){int d=(x-226)*(x-226)+(y-25)*(y-25);if((d>=42&&d<=57)||(d>=122&&d<=147))g.drawPixel(x,y,CYAN);}
 }else {g.drawLine(222,15,230,23,RED);g.drawLine(230,15,222,23,RED);}
}
void footer(const char* left,const char* right){g.fillRect(0,304,240,16,0x0000);type(left,8,316,f_micro,MUTED);type(right,232,316,f_micro,CYAN,2);}
void heading(const char* left,const char* right){type(left,12,46,f_micro,CYAN);type(right,228,46,f_micro,WHITE,2);g.drawFastHLine(12,54,216,0x03BF);}
const Photo& conditionPhoto(int code){
 if(code==0)return photoSun;if(code<=3||code==45||code==48)return photoCloud;
 if((code>=71&&code<=77)||(code>=85&&code<=86))return photoSnow;
 return photoRain;
}
const char* conditionName(int code){
 if(code==0)return tr("Slonecznie","Clear");if(code<=3)return tr("Zachmurzenie","Cloudy");
 if(code==45||code==48)return tr("Mgla","Fog");if(code>=95)return tr("Burza","Thunderstorm");
 if((code>=71&&code<=77)||(code>=85&&code<=86))return tr("Snieg","Snow");return tr("Deszcz","Rain");
}
void drawWeather(int which,uint32_t now){
 base();cityBanner(now);char s[64];
 const char* status=WiFi.status()!=WL_CONNECTED?"OFFLINE":!wx.valid?tr("LACZENIE","CONNECTING"):now-wx.received>1800000?tr("STARE DANE","STALE DATA"):"";
 if(which==0){
  if(wx.valid){
   weatherMotion(4,58,100,wx.code,wx.day,now);
   snprintf(s,sizeof(s),"%.0f",wx.temp);const SmoothFont& tf=f_temp; // Same digit size for 14, -20 and 100.
   outlinedType(s,210,139,tf,WHITE,2,true);
   g.drawCircle(218,82,4,0x0000);g.drawCircle(218,82,2,WHITE);billboardType("C",224,108,f_medium,WHITE);
  }else outlinedType("--",210,139,f_temp,WHITE,2,true);
  g.fillRect(0,160,240,144,0x0000);g.drawFastHLine(0,160,240,CYAN);
  type(tr("POGODA TERAZ","WEATHER NOW"),120,188,f_micro,CYAN,1);
  type(wx.valid?conditionName(wx.code):tr("Czekam na dane","Waiting for data"),120,205,f_medium,WHITE,1);
  outlinedType(clockText,120,279,f_big,WHITE,1,true);
  type(dateText,120,299,f_small,WHITE,1);
 }else if(which==1){
  // Forecast has its own uncluttered page, with all three days visible.
  g.fillRect(0,48,240,256,0x0000);
  type(tr("PROGNOZA 3 DNI","3 DAY FORECAST"),120,73,f_medium,CYAN,1);
  for(int i=0;i<3;i++){
   int y=79+i*75;
   const char* pl[]={"Dzisiaj","Jutro","Pojutrze"};const char* en[]={"Today","Tomorrow","Day after"};
   type(language?en[i]:pl[i],90,y+17,f_small,CYAN);
   type("MAX/MIN C",230,y+17,f_micro,MUTED,2);
   if(wx.valid){
    sprite(animatedSymbol(wx.days[i].code,true),10,y+4,64);
    snprintf(s,sizeof(s),"%.0f / %.0f",wx.days[i].hi,wx.days[i].lo);
    // Fixed readable font: do not shrink negative forecasts.
    heavyType(s,90,y+47,f_value,WHITE);
    snprintf(s,sizeof(s),"%s %d%%",tr("Opady","Rain"),wx.days[i].rain);
    type(s,90,y+65,f_small,CYAN);
   }else heavyType("-- / --",90,y+47,f_value,WHITE);
   if(i<2)g.drawFastHLine(10,y+73,220,0x4208);
  }
 }else if(which==2){
  g.fillRect(0,48,240,256,0x0000);
  type(tr("WARUNKI","CONDITIONS"),120,74,f_medium,CYAN,1);
  const char* labelsPL[]={"Cisnienie","Wiatr","Wilgotnosc"};const char* labelsEN[]={"Pressure","Wind","Humidity"};
  for(int i=0;i<3;i++){
   int y=87+i*71;
   if(i==0)pressureIcon(34,y+33);else if(i==1)windIcon(34,y+29);else humidityIcon(34,y+29);
   type(language?labelsEN[i]:labelsPL[i],65,y+17,f_small,CYAN);
   if(wx.valid){
    if(i==0)snprintf(s,sizeof(s),"%.0f",wx.pressure);
    else if(i==1)snprintf(s,sizeof(s),"%.1f",wx.wind);
    else snprintf(s,sizeof(s),"%d",wx.humidity);
   }else strcpy(s,"--");
   heavyType(s,65,y+49,f_value,WHITE);
   type(i==0?"hPa":i==1?"km/h":"%",224,y+49,f_small,WHITE,2);
   if(i<2)g.drawFastHLine(65,y+64,159,0x4208);
  }
 }else {
  heading(tr("CZAS LOKALNY","LOCAL TIME"),status);outlinedType(clockText,120,202,f_xl,WHITE,1,true);glass(16,208,208,51,130);minuteProgress(now);billboardType(dateText,120,274,f_medium,WHITE,1);
  type(language?countries[country].en:countries[country].pl,120,295,f_small,MUTED,1);
 }
 snprintf(s,sizeof(s),"%d / 4",which+1);footer("PSH: MENU",s);
}
const Sprite* reelSymbols[]={&sp_cherry,&sp_lemon,&sp_seven,&sp_gem,&sp_bell,&sp_bar};
void drawOther(){
 uint32_t now=frameAt;
 base();char s[64];
 if(mode==MENU||mode==LANGUAGE||mode==COUNTRY){
  cityBanner(now);heading(mode==MENU?"MENU":mode==LANGUAGE?tr("JEZYK","LANGUAGE"):tr("KRAJ","COUNTRY"),"KORA 5.9");
  const char* pl[]={"Pogoda","Lucky Reels","Lotto 6/59","Neon Snake","Prism Breakout","Pac-Man","Space Invaders","Tetris / Neon Blocks","Jezyk: PL / EN","Kraj / miasto"};
  const char* en[]={"Weather","Lucky Reels","Lotto 6/59","Neon Snake","Prism Breakout","Pac-Man","Space Invaders","Tetris / Neon Blocks","Language: PL / EN","Country / city"};
  int count=mode==MENU?10:mode==LANGUAGE?2:4, selected=mode==MENU?menuIndex:choice;
  int first=mode==MENU?constrain(selected-2,0,count-5):0;glass(8,134,224,161,225);
  for(int row=0;row<min(5,count);row++){
   int i=first+row,y=141+row*31;
   if(i==selected){g.fillRoundRect(8,y,224,28,6,0x03BF);g.fillRect(8,y+7,3,14,CYAN);}
   const char* title=mode==MENU?(language?en[i]:pl[i]):mode==LANGUAGE?(i?"English":"Polski"):(language?countries[i].en:countries[i].pl);
   type(title,20,y+20,f_medium,i==selected?WHITE:MUTED);
  }
  footer(tr("OBROT: WYBOR","TURN: SELECT"),"PSH: OK");return;
 }
 if(mode!=SLOT&&mode!=LOTTO)return;
 type(mode==SLOT?"LUCKY REELS":"LOTTO 6 / 59",120,32,f_medium,GOLD,1);
 if(mode==SLOT){
  for(int i=0;i<3;i++){
   int x=7+i*77;g.fillRoundRect(x,82,72,151,8,0x324C);g.fillRoundRect(x+3,85,66,145,6,0xFFFF);
   int cell=int(floorf(reelPos[i])),offset=int((reelPos[i]-cell)*64);
   for(int k=-2;k<=2;k++){
    const Sprite& sp=*reelSymbols[((cell+k)%6+6)%6];int sy=126+k*64-offset;
    for(int yy=max(max(86,sy),g.top);yy<min(min(229,sy+64),g.top+16);yy++)for(int xx=0;xx<64;xx++){
     int p=(yy-sy)*64+xx;ink(x+4+xx,yy,pgm_read_word(sp.rgb+p),pgm_read_byte(sp.alpha+p));}
   }
   g.drawRoundRect(x,82,72,151,8,GOLD);
  }
  g.drawFastHLine(8,158,224,RED);
  const char* message=spinning?tr("Powodzenia!","Good luck!"):reelPos[0]==reelPos[1]&&reelPos[1]==reelPos[2]?tr("Trzy takie same!","Three of a kind!"):tr("PSH: zakrec","PSH: spin");
  type(message,120,266,f_medium,GOLD,1);
 }else {
  type(tr("Twoj zestaw liczb","Your number selection"),120,64,f_small,MUTED,1);
  for(int i=0;i<6;i++){int x=43+(i%3)*77,y=122+(i/3)*85;
   g.fillCircle(x,y+3,29,0x0002);g.fillCircle(x,y,28,0x2576);g.drawCircle(x,y,28,CYAN);g.fillCircle(x-10,y-11,5,0x86DC);
   snprintf(s,sizeof(s),"%02d",lotto[i]);type(s,x,y+10,f_value,WHITE,1);}
  type(tr("Generator, nie wyniki losowan","Generator, not lottery results"),120,270,f_micro,MUTED,1);
 }
 footer("PSH: PLAY","BAK: MENU");
}
