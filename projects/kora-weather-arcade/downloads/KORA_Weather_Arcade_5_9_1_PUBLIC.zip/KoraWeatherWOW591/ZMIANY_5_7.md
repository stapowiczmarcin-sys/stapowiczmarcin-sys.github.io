# KORA 5.7

- Temperatura 14, -20 i 100 korzysta z tej samej dużej czcionki.
- Białe cyfry temperatury i zegara pogrubione w poziomie i pionie; czarna obwódka pozostaje.
- Ikona pogody przesunięta i pomniejszona, aby pozostawić miejsce na minus i trzy cyfry.
- Brak testu na fizycznym ekranie; podgląd wykorzystuje rzeczywiste bitmapy czcionek.
