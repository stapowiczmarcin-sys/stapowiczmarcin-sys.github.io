#pragma once
#include <stdint.h>
enum HoldAction { HOLD_NONE, HOLD_PAUSE, HOLD_MENU };
// Debounced hold: pause on a medium release, exit while a long hold is down.
// Waiting for release to pause prevents resuming a paused game during an exit hold.
struct GameHold {
  bool raw=false,stable=false,exited=false;
  uint32_t changedAt=0,startedAt=0,elapsed=0;
  static constexpr uint32_t DEBOUNCE=22,PAUSE_MS=650,EXIT_MS=1250;
  void reset(){raw=false;stable=false;exited=false;changedAt=startedAt=elapsed=0;}
  bool consuming() const {return stable&&(exited||elapsed>=PAUSE_MS);}
  HoldAction poll(bool down,uint32_t now,bool enabled=true){
    if(!enabled){reset();return HOLD_NONE;}
    if(down!=raw){raw=down;changedAt=now;}
    if(now-changedAt>=DEBOUNCE&&raw!=stable){
      stable=raw;
      if(stable){startedAt=changedAt;exited=false;}
      else {bool wasExit=exited;exited=false;
        if(!wasExit&&changedAt-startedAt>=EXIT_MS)return HOLD_MENU;
        if(!wasExit&&changedAt-startedAt>=PAUSE_MS)return HOLD_PAUSE;
      }
    }
    elapsed=stable?now-startedAt:0;
    if(stable&&raw){
      if(!exited&&now-startedAt>=EXIT_MS){exited=true;return HOLD_MENU;}
    }
    return HOLD_NONE;
  }
};
