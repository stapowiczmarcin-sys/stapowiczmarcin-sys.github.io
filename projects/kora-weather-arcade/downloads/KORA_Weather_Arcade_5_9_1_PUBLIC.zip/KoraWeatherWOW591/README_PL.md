# KORA Weather WOW 5.9 / ESP32-C3 + ILI9341

PL: Otwórz KoraWeatherWOW591.ino. Wpisz własne WIFI_SSID i WIFI_PASS. Cały folder musi pozostać razem ze wszystkimi plikami .h. ESP32C3 Dev Module, flash 4 MB, Huge APP (3MB No OTA/1MB SPIFFS), USB CDC On Boot Enabled. Biblioteki: Adafruit GFX, Adafruit ILI9341, Adafruit BusIO, ArduinoJson 7. Pogoda z Open-Meteo, bez klucza API. Cztery widoki: pogoda, 3 dni prognozy, ciśnienie/wiatr/wilgotność, zegar. PL/EN, cztery kraje, Snake, Breakout, Pac-Man, Space Invaders, Neon Blocks (Tetris), Lucky Reels oraz generator Lotto. Przycisk enkodera: wybór/start/pauza; dodatkowy BAK: powrót. Ekran 240x320 pionowo.

EN: Open KoraWeatherWOW591.ino and enter your own WIFI_SSID / WIFI_PASS. Keep every .h file next to the sketch. Select ESP32C3 Dev Module, 4 MB flash, Huge APP, USB CDC On Boot Enabled. Install Adafruit GFX, Adafruit ILI9341, Adafruit BusIO and ArduinoJson 7. Open-Meteo requires no API key. Weather, three-day forecast, pressure/wind/humidity and local clock; PL/EN; four city presets and seven games/tools.

## Wiring / Połączenia
TFT: VCC and LED 3.3V (verify your module), GND-GND, CS-GPIO10, RESET-GPIO5, DC-GPIO4, SDI/MOSI-GPIO7, SCK-GPIO6, SDO/MISO-GPIO2 (optional if SDO absent). SD card is not used.
Encoder: A/CLK-GPIO0, B/DT-GPIO1, SW-GPIO9, common-GND. If encoder module requires VCC use 3.3V. Back button: GPIO8 to GND. Release SW and BAK during power-up/reset; GPIO2/8/9 are boot strapping pins.

PL: Schemat na stronie dotyczy wersji USB. Obudowa ma miejsce na koszyk 18650, lecz model modułu zasilania baterii nie został jeszcze potwierdzony. Nie podłączaj ogniwa bezpośrednio do 3V3. Zdjęcia strony to opisany prototyp i podglądy programowe z przykładowymi danymi. Model STL nie był fizycznie drukowany.
EN: Wiring covers USB power. Enclosure fits an 18650 holder; the battery power/charging module is not yet specified. Do not connect a cell directly to 3V3. Software previews use sample weather data. STL geometry was verified; no physical test print yet.

Compile: see WERYFIKACJA.md for current verification results. Photo sources: ZRODLA.md.

## Widocznosc 5.9 / Legibility 5.9
PL: Temperatura 14, -20 i 100 ma te sama duza czcionke. Cyfry temperatury i zegara pogrubiono o 2 px w poziomie i 1 px w pionie. Czarna obwodka ma 2 px. Ikona pogody pozostawia miejsce na minus i trzy cyfry.
EN: 14, -20 and 100 use the same large temperature font. Temperature and clock glyphs expand by 2 px horizontally and 1 px vertically, with a 2 px black outline. The weather icon leaves room for negative and three-digit readings.


## Czytelniejszy ekran 5.9 / Larger display layout 5.9

EN: Forecast icons increased from 30 to 64 pixels. Each day has a separate 75-pixel row: large weather symbol, day label, bold maximum/minimum temperatures and precipitation probability. The home weather clock now uses the 84-pixel numeral font instead of the 30-pixel font; temperature increases from 72 to 84 pixels. The separate clock screen uses a 90-pixel font. Temperature and time retain white bold digits and black outlines. Readings 14, -20 and 100 keep the same temperature size.

PL: Ikony prognozy powiększono z 30 do 64 pikseli. Każdy dzień ma wiersz o wysokości 75 pikseli: duży symbol pogody, nazwę dnia, pogrubioną temperaturę maksymalną/minimalną i prawdopodobieństwo opadów. Godzina na ekranie pogody używa fontu 84 px zamiast 30 px; temperatura zwiększa się z 72 do 84 px. Osobna strona zegara używa fontu 90 px. Cyfry pozostają białe, pogrubione i z czarną obwódką. Temperatura 14, -20 i 100 zachowuje ten sam rozmiar.

EN: Extract the complete ZIP and open KoraWeatherWOW591/KoraWeatherWOW591.ino. Enter your Wi-Fi details. Replace the complete sketch folder, including every header; the new fonts are in VisualAssets.h. Software previews use example readings and are not photographs of a physical TFT.

PL: Rozpakuj cały ZIP i otwórz KoraWeatherWOW591/KoraWeatherWOW591.ino. Wpisz dane Wi-Fi. Użyj kompletnego folderu z wszystkimi nagłówkami; nowe czcionki są w VisualAssets.h. Podglądy programowe używają przykładowych danych, nie są fotografią fizycznego TFT.


## Version 5.9 / Wersja 5.9

EN: Animated birds now appear over London, Warsaw, Madrid and New York. Their silhouettes are drawn after the dark header shade so they remain visible. The main weather symbol increases from 68 to 100 px. Temperature digits keep their previous 84-pixel height, bold fill and black outline; their width is condensed to leave room for the larger symbol, including -20. Large clocks and 64px forecast symbols remain.

PL: Animowane ptaki lecą nad Londynem, Warszawą, Madrytem i Nowym Jorkiem. Sylwetki są rysowane po przyciemnieniu nagłówka, by pozostały widoczne. Główny symbol pogody zwiększa się z 68 do 100 px. Temperatura zachowuje wysokość fontu 84 px, pogrubienie i czarną obwódkę; cyfry są węższe, aby zmieścić większą ikonę, także przy -20. Zachowano duże zegary i symbole prognozy 64px.

### Neon Blocks / Tetris-style falling blocks

EN: Original falling-block game inspired by the classic 1980s game. Seven pieces, shuffled bags, line scoring, increasing speed, next-piece preview and landing ghost. Turn the encoder to move left/right. One short press starts, resumes, rotates clockwise, or restarts after loss. Double press drops instantly. Hold for 0.65–1.24 seconds and release to pause/resume; hold for 1.3 seconds to exit to the menu. BAK returns to the menu; double press still returns to the menu in the other games. Paused and game-over screens remain in the arcade renderer, so Lotto cannot appear behind them.

PL: Autorska gra w spadające klocki inspirowana klasykiem z lat 80. Siedem kształtów, tasowane zestawy, punkty za linie, rosnąca szybkość, podgląd następnego klocka i obrys miejsca lądowania. Obrót enkodera przesuwa klocek w lewo/prawo. Krótkie naciśnięcie uruchamia, wznawia, obraca w prawo lub restartuje po przegranej. Dwuklik natychmiast zrzuca klocek. Przytrzymanie 0,65–1,24 s i puszczenie przełącza pauzę; przytrzymanie 1,3 s wraca do menu. BAK wraca do menu; w pozostałych grach dwuklik nadal wraca do menu. Pauza i przegrana pozostają w renderowaniu gry, bez fragmentów Lotto.

EN: Use the complete KoraWeatherWOW591 folder. Open KoraWeatherWOW591.ino, enter Wi-Fi details and upload with your existing ESP32-C3 / Huge APP / USB CDC settings. New TetrisGame.h, HoldControls.h and updated VisualAssets.h are required. Software previews/GIF show sample data and illustrative game positions; they are not hardware recordings or frame-rate measurements.

PL: Użyj całego folderu KoraWeatherWOW591. Otwórz KoraWeatherWOW591.ino, wpisz dane Wi-Fi i wgraj z dotychczasowymi ustawieniami ESP32-C3 / Huge APP / USB CDC. Wymagane są TetrisGame.h, HoldControls.h i zaktualizowany VisualAssets.h. Podglądy i GIF mają przykładowe dane oraz ilustracyjne ułożenie gry; nie są nagraniem urządzenia ani pomiarem płynności.


# 5.9.1 — encoder-only exit / wyjście samym enkoderem
EN: In Neon Blocks, hold the encoder button for 1.3 seconds to return to the menu from play, pause, start or game over. A medium hold (0.65–1.24 seconds), then release, toggles pause. Short click rotates/starts, double-click drops; BAK still returns to the menu. Exit suppresses the release click so it cannot reopen the game.

PL: W Neon Blocks przytrzymaj przycisk enkodera przez 1,3 sekundy, aby wyjść do menu podczas gry, pauzy, przed startem lub po przegranej. Przytrzymanie 0,65–1,24 s i puszczenie przełącza pauzę. Krótki klik obraca/startuje, dwuklik zrzuca; BAK nadal wraca do menu. Puszczenie po wyjściu nie wybiera gry ponownie.
