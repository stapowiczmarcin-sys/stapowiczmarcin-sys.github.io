#pragma once
void gameBase(const char* title,int score,int lives=-1){
 base();char s[40];
 for(int i=0;i<30;i++){int x=12+(i*67)%216,y=54+int((i*41+frameAt/160)%244);g.drawPixel(x,y,dim565(CYAN,45+(i%3)*25));}
 type(title,13,25,f_medium,0x001F);type(title,12,24,f_medium,CYAN);
 snprintf(s,sizeof(s),lives<0?"%s %d":"%s %d  /  %d",tr("Wynik","Score"),score,lives);
 type(s,12,43,f_small,MUTED);g.drawRoundRect(8,50,224,252,7,0x03FF);
 footer(tr("PSH: GRA","PSH: PLAY"),"BAK: MENU");
}
void overlay(bool over,bool won=false){
 g.fillRoundRect(18,149,204,78,10,0x0000);g.drawRoundRect(18,149,204,78,10,0x001F);
 g.fillRoundRect(22,153,196,70,8,0x0004);g.drawRoundRect(22,153,196,70,8,CYAN);g.drawFastHLine(37,155,165,GOLD);
 type(over?(won?tr("WYGRANA!","YOU WIN!"):tr("KONIEC GRY","GAME OVER")):tr("PAUZA / START","PAUSED / READY"),120,183,f_medium,WHITE,1);
 type(tr("PSH: graj","PSH: play"),120,203,f_small,CYAN,1);
}
void gameSparks(int score,int cx,int cy){
 static int previousMode=-1,previousScore=0;static uint32_t started=0;
 if(previousMode!=int(mode)){previousMode=mode;previousScore=score;started=0;}
 if(score!=previousScore){previousScore=score;started=frameAt;}
 if(!started||frameAt-started>420)return;
 float age=(frameAt-started)/420.f;
 for(int k=0;k<10;k++){float a=k*PI/5;int x=cx+cosf(a)*(6+age*25),y=cy+sinf(a)*(6+age*25);g.fillCircle(x,y,1,k%2?GOLD:WHITE);}
}
void drawSnake(){
 gameBase("NEON SNAKE",snake.score);
 for(int y=0;y<SnakeGame::H;y++)for(int x=0;x<SnakeGame::W;x++)g.drawPixel(20+x*10+5,65+y*10+5,0x03FF);
 int fx=20+snake.food.x*10+5,fy=65+snake.food.y*10+5;g.drawCircle(fx,fy,6,0x780F);g.drawCircle(fx,fy,5,0xF81F);g.fillCircle(fx,fy,4,0xF81F);g.fillCircle(fx-1,fy-1,1,WHITE);
 for(int i=snake.length-1;i>=0;i--){int x=20+snake.body[i].x*10,y=65+snake.body[i].y*10;g.drawRoundRect(x,y,10,10,3,0x0320);g.fillRoundRect(x+1,y+1,9,9,3,i?0x05E0:GREEN);g.drawFastHLine(x+3,y+2,4,WHITE);}
 int x=25+snake.body[0].x*10,y=70+snake.body[0].y*10;const int dx[]={1,0,-1,0},dy[]={0,1,0,-1};
 for(int side=-1;side<=1;side+=2)g.fillCircle(x+dx[snake.dir]*2-dy[snake.dir]*side*2,y+dy[snake.dir]*2+dx[snake.dir]*side*2,1,0);
 gameSparks(snake.score,fx,fy);
 if(snake.over||snake.paused)overlay(snake.over,snake.won);
}
void drawBreakout(){
 gameBase("PRISM BREAKOUT",breakout.score,breakout.lives);
 const uint16_t colors[]={0xF81F,0x07FF,0x07E0,0xFFE0};
 for(int r=0;r<4;r++)for(int c=0;c<9;c++)if(breakout.bricks[r][c]){int x=23+c*22,y=62+r*18;g.fillRoundRect(x-1,y-1,20,14,3,dim565(colors[r],65));g.fillRoundRect(x,y,18,12,3,colors[r]);g.drawFastHLine(x+3,y+1,12,WHITE);g.drawFastHLine(x+2,y+9,14,dim565(colors[r],150));}
 for(int i=5;i>=0;i--)g.fillCircle(breakout.trailX[i],breakout.trailY[i],2,dim565(CYAN,50+(5-i)*20));
 g.drawCircle(breakout.bx,breakout.by,6,0x001F);g.drawCircle(breakout.bx,breakout.by,4,CYAN);g.fillCircle(breakout.bx,breakout.by,3,WHITE);g.fillRoundRect(breakout.paddle-24,278,48,7,3,CYAN);g.drawFastHLine(breakout.paddle-20,279,40,WHITE);
 gameSparks(breakout.score,breakout.bx,breakout.by);
 if(breakout.over||breakout.paused||breakout.ready)overlay(breakout.over,breakout.won);
}
void drawPacman(){
 gameBase("PAC-MAN",pacman.score,pacman.lives);
 for(int y=0;y<PacmanGame::H;y++)for(int x=0;x<PacmanGame::W;x++){
  int xx=15+x*14,yy=55+y*14;
  if(pacman.wall(x,y)){g.fillRoundRect(xx,yy,14,14,3,0x0008);g.drawRoundRect(xx,yy,14,14,3,0x001F);g.drawRoundRect(xx+2,yy+2,10,10,2,0x03FF);g.drawFastHLine(xx+4,yy+2,6,WHITE);}
  else if(pacman.pellets[y][x])g.fillCircle(xx+7,yy+7,((x==1||x==13)&&(y==1||y==15))?3:1,GOLD);
 }
 int cx=22+pacman.x*14,cy=62+pacman.y*14;g.drawCircle(cx,cy,7,0xA500);g.fillCircle(cx,cy,6,GOLD);g.drawPixel(cx-2,cy-3,WHITE);
 const int dx[]={1,0,-1,0},dy[]={0,1,0,-1};int d=pacman.dir;
 if((frameAt/110)%2)g.fillTriangle(cx,cy,cx+dx[d]*8-dy[d]*4,cy+dy[d]*8+dx[d]*4,cx+dx[d]*8+dy[d]*4,cy+dy[d]*8-dx[d]*4,PANEL);
 const uint16_t colors[]={RED,CYAN,0xF81F};
 for(int i=0;i<3;i++){
  int x=22+pacman.ghosts[i].x*14,y=62+pacman.ghosts[i].y*14;uint16_t c=pacman.power?0x001F:colors[i];
  g.drawCircle(x,y-1,7,dim565(c,80));g.fillCircle(x,y-1,6,c);g.drawFastHLine(x-2,y-5,4,WHITE);g.fillRect(x-6,y-1,13,7,c);
  for(int j=-1;j<=1;j++)g.fillTriangle(x+j*4-2,y+6,x+j*4,y+3,x+j*4+2,y+6,PANEL);
  g.fillCircle(x-3,y-1,2,WHITE);g.fillCircle(x+3,y-1,2,WHITE);g.drawPixel(x-3,y-1,0);g.drawPixel(x+3,y-1,0);
 }
 gameSparks(pacman.score,cx,cy);
 if(pacman.over||pacman.paused)overlay(pacman.over,pacman.won);
}
// Hand-drawn original 11 x 8 arcade sprites, two walk animation frames.
const uint16_t alienFrames[2][8]={{0x104,0x088,0x1FC,0x36E,0x7FF,0x5FD,0x504,0x088},{0x104,0x488,0x5FD,0x7FF,0x36E,0x1FC,0x088,0x104}};
void drawInvaders(){
 gameBase("SPACE INVADERS",invaders.score,invaders.lives);
 for(int i=0;i<28;i++)g.drawPixel(13+(i*73)%211,54+(i*43)%237,dim565(WHITE,40+(i%4)*30));
 const uint16_t colors[]={0xF81F,0xFFE0,CYAN,GREEN};int frame=(frameAt/250)%2;
 for(int r=0;r<4;r++)for(int c=0;c<8;c++)if(invaders.alive[r][c])for(int yy=0;yy<8;yy++)for(int xx=0;xx<11;xx++)if(alienFrames[frame][yy]&(1<<(10-xx))){int x=invaders.ox+c*23-11+xx*2,y=invaders.oy+r*22+yy*2;g.fillRect(x,y,2,2,colors[r]);if(yy==2)g.drawPixel(x,y,WHITE);}
 int x=invaders.ship;g.fillTriangle(x,273,x-12,287,x+12,287,CYAN);g.fillRect(x-3,269,7,16,WHITE);g.fillRect(x-10,287,5,3,RED);g.fillRect(x+5,287,5,3,RED);
 if(invaders.shotY>=0)g.fillRoundRect(invaders.shotX-1,invaders.shotY,3,7,1,GREEN);
 if(invaders.enemyY>=0)g.fillRoundRect(invaders.enemyX-1,invaders.enemyY,3,7,1,RED);
 gameSparks(invaders.score,120,145);
 if(invaders.over||invaders.paused)overlay(invaders.over,invaders.won);
}
const uint16_t blockColors[]={0x07FF,0x03FF,0xFC60,0xFFE0,0x07E0,0xF81F,0xF800};
void blockTile(int x,int y,int kind,int size=11,bool ghost=false){
 uint16_t c=blockColors[kind];
 if(ghost){g.drawRoundRect(x+1,y+1,size-2,size-2,2,dim565(c,90));return;}
 g.fillRoundRect(x,y,size-1,size-1,2,dim565(c,80));
 g.fillRect(x+1,y+1,size-3,size-3,c);
 g.drawFastHLine(x+2,y+1,size-5,WHITE);g.drawFastVLine(x+1,y+2,size-5,dim565(WHITE,170));
 g.drawFastHLine(x+2,y+size-3,size-5,dim565(c,130));
}
void drawTetris(){
 gameBase("NEON BLOCKS",tetris.score);
 g.fillRect(14,62,112,222,0x0000);g.drawRect(13,61,114,224,0x03FF);
 for(int y=0;y<TetrisGame::H;y++)for(int x=0;x<TetrisGame::W;x++){
  int px=15+x*11,py=63+y*11;
  g.drawPixel(px+5,py+5,0x18C3);
  if(tetris.board[y][x])blockTile(px,py,tetris.board[y][x]-1);
 }
 if(!tetris.over){
  int ghost=tetris.ghostY();
  for(int y=0;y<4;y++)for(int x=0;x<4;x++)if(TetrisGame::cell(tetris.kind,tetris.rotation,x,y)){
   if(ghost+y>=0)blockTile(15+(tetris.x+x)*11,63+(ghost+y)*11,tetris.kind,11,true);
   if(tetris.y+y>=0)blockTile(15+(tetris.x+x)*11,63+(tetris.y+y)*11,tetris.kind);
  }
 }
 type(tr("NASTEPNY","NEXT"),139,77,f_micro,CYAN);
 g.fillRoundRect(138,85,86,61,5,0x0843);g.drawRoundRect(138,85,86,61,5,0x001F);
 for(int y=0;y<4;y++)for(int x=0;x<4;x++)if(TetrisGame::cell(tetris.next,0,x,y))blockTile(151+x*15,89+y*15,tetris.next,15);
 char s[24];type(tr("POZIOM","LEVEL"),139,169,f_small,CYAN);snprintf(s,sizeof(s),"%d",tetris.level);heavyType(s,139,194,f_value,WHITE);
 type(tr("LINIE","LINES"),139,218,f_small,CYAN);snprintf(s,sizeof(s),"%d",tetris.lines);heavyType(s,139,244,f_value,GOLD);
 type(tr("1x OBROT","1x ROTATE"),139,267,f_micro,WHITE);type(tr("2x ZRZUT","2x DROP"),139,282,f_micro,WHITE);
 gameSparks(tetris.score,70,160);
 if(tetris.over||tetris.paused)overlay(tetris.over);
 footer(tr("1,3s: MENU","1.3s: MENU"),"BAK: MENU");
}
void drawArcade(){switch(mode){case SNAKE:drawSnake();break;case BREAKOUT:drawBreakout();break;case PACMAN:drawPacman();break;case INVADERS:drawInvaders();break;case TETRIS:drawTetris();break;default:break;}}
