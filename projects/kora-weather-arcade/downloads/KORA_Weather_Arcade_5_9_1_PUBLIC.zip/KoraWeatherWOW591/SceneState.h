#pragma once
enum Mode { WEATHER, MENU, SLOT, LOTTO, SNAKE, BREAKOUT, PACMAN, INVADERS, TETRIS, LANGUAGE, COUNTRY };
constexpr bool isArcadeMode(Mode m){return m==SNAKE||m==BREAKOUT||m==PACMAN||m==INVADERS||m==TETRIS;}
constexpr bool hasCityBanner(Mode m){return m==WEATHER||m==MENU||m==LANGUAGE||m==COUNTRY;}
// Regression: these must remain game scenes on death, pause and restart.
static_assert(isArcadeMode(PACMAN)&&isArcadeMode(INVADERS)&&isArcadeMode(SNAKE)&&isArcadeMode(BREAKOUT)&&isArcadeMode(TETRIS),"All arcade modes must use arcade renderer");
static_assert(!isArcadeMode(LOTTO)&&!isArcadeMode(SLOT)&&!isArcadeMode(MENU),"Other modes must not use arcade renderer");
