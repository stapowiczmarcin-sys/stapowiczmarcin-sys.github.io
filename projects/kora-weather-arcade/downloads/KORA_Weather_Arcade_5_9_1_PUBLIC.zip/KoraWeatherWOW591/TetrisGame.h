#pragma once
#include <stdint.h>
// Original falling-block implementation. No display/Arduino dependency.
struct TetrisGame {
 static constexpr int W=10,H=20;
 // I, J, L, O, S, T, Z; four clockwise orientations, row-major 4x4.
 static constexpr uint16_t shapes[7][4]={
  {0x0F00,0x2222,0x00F0,0x4444},
  {0x8E00,0x6440,0x0E20,0x44C0},
  {0x2E00,0x4460,0x0E80,0xC440},
  {0x6600,0x6600,0x6600,0x6600},
  {0x6C00,0x4620,0x06C0,0x8C40},
  {0x4E00,0x4640,0x0E40,0x4C40},
  {0xC600,0x2640,0x0C60,0x4C80}};
 uint8_t board[H][W]={},bag[7]={};
 int bagPos=7,kind=0,next=0,rotation=0,x=3,y=0;
 int score=0,lines=0,level=1,lastClear=0,lockResets=0;
 bool paused=true,over=false,grounded=false;
 uint32_t fallAt=0,groundAt=0;uint32_t (*rng)(uint32_t)=nullptr;
 static bool cell(int piece,int rot,int xx,int yy){
  return xx>=0&&xx<4&&yy>=0&&yy<4&&(shapes[piece][rot&3]&(0x8000u>>(yy*4+xx)));
 }
 bool fits(int piece,int rot,int px,int py)const{
  for(int yy=0;yy<4;yy++)for(int xx=0;xx<4;xx++)if(cell(piece,rot,xx,yy)){
   int bx=px+xx,by=py+yy;
   if(bx<0||bx>=W||by>=H)return false;
   if(by>=0&&board[by][bx])return false;
  }return true;
 }
 int draw(){
  if(bagPos>=7){for(int i=0;i<7;i++)bag[i]=i;
   for(int i=6;i>0;i--){int j=rng?int(rng(i+1)):0;uint8_t t=bag[i];bag[i]=bag[j];bag[j]=t;}bagPos=0;}
  return bag[bagPos++];
 }
 void spawn(uint32_t now){
  kind=next;next=draw();rotation=0;x=3;y=0;grounded=false;lockResets=0;fallAt=now;
  if(!fits(kind,rotation,x,y))over=true;
 }
 void reset(uint32_t now,uint32_t(*randomFn)(uint32_t)){
  rng=randomFn;bagPos=7;score=lines=lastClear=0;level=1;paused=true;over=false;
  for(int yy=0;yy<H;yy++)for(int xx=0;xx<W;xx++)board[yy][xx]=0;
  next=draw();spawn(now);
 }
 uint32_t interval()const{int n=720-(level-1)*45;return n<90?90:n;}
 int ghostY()const{int gy=y;while(fits(kind,rotation,x,gy+1))gy++;return gy;}
 void adjustLock(uint32_t now){
  if(grounded&&lockResets<8){groundAt=now;lockResets++;}
  if(fits(kind,rotation,x,y+1))grounded=false;
 }
 void move(int steps,uint32_t now){
  if(paused||over)return;int sign=steps>0?1:-1;int count=steps>0?steps:-steps;if(count>10)count=10;
  while(count--)if(fits(kind,rotation,x+sign,y)){x+=sign;adjustLock(now);}else break;
 }
 bool rotate(uint32_t now){
  if(paused||over)return false;int rot=(rotation+1)&3;const int kick[]={0,-1,1,-2,2};
  for(int up=0;up<=2;up++)for(int i=0;i<5;i++)if(fits(kind,rot,x+kick[i],y-up)){
   x+=kick[i];y-=up;rotation=rot;adjustLock(now);return true;
  }return false;
 }
 int clearLines(){
  int count=0;
  for(int yy=H-1;yy>=0;yy--){bool full=true;for(int xx=0;xx<W;xx++)if(!board[yy][xx])full=false;
   if(full){count++;for(int row=yy;row>0;row--)for(int xx=0;xx<W;xx++)board[row][xx]=board[row-1][xx];
    for(int xx=0;xx<W;xx++)board[0][xx]=0;yy++;}
  }return count;
 }
 void lock(uint32_t now){
  for(int yy=0;yy<4;yy++)for(int xx=0;xx<4;xx++)if(cell(kind,rotation,xx,yy)){
   int by=y+yy;if(by<0){over=true;return;}board[by][x+xx]=kind+1;
  }
  lastClear=clearLines();const int points[]={0,100,300,500,800};score+=points[lastClear]*level;
  lines+=lastClear;level=1+lines/10;spawn(now);
 }
 void hardDrop(uint32_t now){
  if(paused||over)return;int gy=ghostY();score+=(gy-y)*2;y=gy;lock(now);
 }
 void click(uint32_t now){
  if(over){reset(now,rng);paused=false;}
  else if(paused){paused=false;fallAt=groundAt=now;}
  else rotate(now);
 }
 void togglePause(uint32_t now){if(over)return;paused=!paused;fallAt=groundAt=now;}
 bool update(uint32_t now){
  if(paused||over)return false;bool changed=false;
  if(now-fallAt>=interval()){fallAt=now;if(fits(kind,rotation,x,y+1)){y++;grounded=false;changed=true;}}
  if(!fits(kind,rotation,x,y+1)){
   if(!grounded){grounded=true;groundAt=now;}
   if(now-groundAt>=300){lock(now);return true;}
  }else grounded=false;
  return changed;
 }
};

