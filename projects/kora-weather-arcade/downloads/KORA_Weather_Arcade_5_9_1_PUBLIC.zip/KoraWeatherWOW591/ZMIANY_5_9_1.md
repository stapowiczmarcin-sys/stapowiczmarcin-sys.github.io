# 5.9.1 — encoder-only exit / wyjście samym enkoderem
EN: In Neon Blocks, hold the encoder button for 1.3 seconds to return to the menu from play, pause, start or game over. A medium hold (0.65–1.24 seconds), then release, toggles pause. Short click rotates/starts, double-click drops; BAK still returns to the menu. Exit suppresses the release click so it cannot reopen the game.

PL: W Neon Blocks przytrzymaj przycisk enkodera przez 1,3 sekundy, aby wyjść do menu podczas gry, pauzy, przed startem lub po przegranej. Przytrzymanie 0,65–1,24 s i puszczenie przełącza pauzę. Krótki klik obraca/startuje, dwuklik zrzuca; BAK nadal wraca do menu. Puszczenie po wyjściu nie wybiera gry ponownie.
