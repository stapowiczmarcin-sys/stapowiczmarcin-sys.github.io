// KORA Weather WOW 5.9.1 / ESP32-C3 Super Mini / ILI9341 portrait
// Libraries: Adafruit GFX, Adafruit ILI9341, Adafruit BusIO, ArduinoJson 7
// Board: ESP32C3 Dev Module. No PSRAM required.
#include <Arduino.h>
#include <SPI.h>
#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>
#include <Adafruit_GFX.h>
#include <Adafruit_ILI9341.h>
#include "VisualAssets.h"
#include "GameLogic.h"
#include "NewGames.h"
#include "TetrisGame.h"
#include "HoldControls.h"
#include <Preferences.h>
#include "Photos.h"
#include <time.h>
#include <math.h>
#include <esp_system.h>
#include <freertos/FreeRTOS.h>
#include <freertos/queue.h>

const char* WIFI_SSID = "YOUR_WIFI_SSID";
const char* WIFI_PASS = "YOUR_WIFI_PASSWORD";
const char* LAT = "52.044";
const char* LON = "0.9514";
const char* TZ_UK = "GMT0BST,M3.5.0/1,M10.5.0/2";
constexpr int CS=10, RST=5, DC=4, MOSI_PIN=7, SCK_PIN=6, MISO_PIN=2;
constexpr int TRA=0, TRB=1, PSH=9, BAK=8;
constexpr uint32_t PAGE_MS=5000, TRANSITION_MS=600;
constexpr int ENCODER_DIRECTION=-1; // Reversed relative to version 4.2; set +1 for the original direction.
SPIClass spi(FSPI);
Adafruit_ILI9341 tft(&spi, DC, CS, RST);

// One 240 x 16 strip, shared by all views: 7,680 bytes.
// Global scene coordinates are clipped into this strip before SPI transfer.
class Strip : public Adafruit_GFX {
 public:
  GFXcanvas16 pixels;
  int top=0, shift=0;
  Strip():Adafruit_GFX(240,320),pixels(240,16) {}
  void drawPixel(int16_t x,int16_t y,uint16_t c) override {
    pixels.drawPixel(x+shift,y-top,c);
  }
  void fillRect(int16_t x,int16_t y,int16_t w,int16_t h,uint16_t c) override {
    pixels.fillRect(x+shift,y-top,w,h,c);
  }
  void drawFastHLine(int16_t x,int16_t y,int16_t w,uint16_t c) override {
    pixels.drawFastHLine(x+shift,y-top,w,c);
  }
  void drawFastVLine(int16_t x,int16_t y,int16_t h,uint16_t c) override {
    pixels.drawFastVLine(x+shift,y-top,h,c);
  }
} g;
constexpr uint16_t WHITE=0xFFFF, MUTED=0xCE79, CYAN=0x07FF;
constexpr uint16_t GOLD=0xFFE0, RED=0xF800, GREEN=0x07E0, PANEL=0x0843;

struct Day { float lo=0,hi=0; int code=0,rain=0; char date[11]=""; };
struct Weather {
  bool valid=false,day=true;
  int countryId=0;
  float temp=0,wind=0,pressure=0,direction=0;
  int humidity=0,code=0;
  uint32_t received=0;
  Day days[3];
};
struct CountrySpec {const char* pl;const char* en;const char* city;const char* lat;const char* lon;const char* tz;const char* apiTz;const Photo* photo;};
const CountrySpec countries[]={
 {"Wielka Brytania","United Kingdom","LONDON","51.5074","-0.1278","GMT0BST,M3.5.0/1,M10.5.0/2","Europe%2FLondon",&photoLondon},
 {"Polska","Poland","WARSZAWA","52.2297","21.0122","CET-1CEST,M3.5.0/2,M10.5.0/3","Europe%2FWarsaw",&photoWarsaw},
 {"Hiszpania","Spain","MADRID","40.4168","-3.7038","CET-1CEST,M3.5.0/2,M10.5.0/3","Europe%2FMadrid",&photoMadrid},
 {"USA","USA","NEW YORK","40.7128","-74.0060","EST5EDT,M3.2.0/2,M11.1.0/2","America%2FNew_York",&photoNewYork}};
Preferences prefs;
int country=0,language=0,choice=0;
QueueHandle_t requestQueue;
const char* tr(const char* pl,const char* en){return language?en:pl;}
Weather wx;
QueueHandle_t weatherQueue;
#include "SceneState.h"
Mode mode=WEATHER;
SnakeGame snake;
BreakoutGame breakout;
PacmanGame pacman;
InvadersGame invaders;
TetrisGame tetris;
Clicks pshClicks;
GameHold tetrisHold;
bool inputGuard=false;
uint32_t inputGuardAt=0;
int page=0,nextPage=1,menuIndex=0;
ClickAction queuedClick=CLICK_NONE;
bool queuedBack=false,queuedTetrisPause=false;
int clipLeft=0,clipRight=240;
uint32_t pageAt=0,slideAt=0,frameAt=0;
bool sliding=false,dirty=true,spinning=false;
int lotto[6]={0};
float reelPos[3]={0,1,2},reelStart[3],reelTravel[3];
uint32_t spinAt=0;
const uint32_t reelDuration[3]={2400,3100,3800};
char slotMessage[32]="PSH: ZAKREC";
time_t sceneUtc=0;
char clockText[8]="--:--",dateText[24]="-- / -- / ----";

// Explicit prototypes keep Arduino's generated prototypes simple.
void networkTask(void*);
bool fetchWeather(Weather&,int);
void drawWeather(int,uint32_t);
void render(uint32_t);
void drawArcade();
void sampleControls(uint32_t now);


uint32_t randomBelow(uint32_t bound) {
  uint32_t r,limit=(-bound)%bound;
  do { r=esp_random(); } while(r<limit);
  return r%bound;
}
#include "VisualUI.h"
#include "ArcadeUI.h"
void render(uint32_t now) {
  sceneUtc=time(nullptr);
  // Scene identity never depends on paused/over/ready state.
  const bool game=isArcadeMode(mode);
  const bool city=hasCityBanner(mode);
  static int lastMode=-1,lastCountry=-1,lastLanguage=-1,lastPage=-1;
  const bool full=lastMode!=int(mode)||lastCountry!=country||lastLanguage!=language;
  const bool content=dirty||lastPage!=page;
  const Mode frameMode=mode;
  for(int y=0;y<320;y+=16){
    bool needed=full||game||(!city&&y>=48)||
      (city&&y<80)||(city&&content&&(mode==WEATHER?y>=48:y>=128))||
      (mode==WEATHER&&page==0&&y>=48&&y<176)||
      (mode==WEATHER&&page==3&&y>=208&&y<272);
    if(!needed)continue;
    g.top=y;g.shift=0;g.pixels.fillScreen(PANEL);
    if(frameMode==WEATHER)drawWeather(page,now);
    else if(isArcadeMode(frameMode))drawArcade();else drawOther();
    tft.drawRGBBitmap(0,y,g.pixels.getBuffer(),240,16);
    sampleControls(millis());yield();
  }
  lastMode=int(frameMode);lastCountry=country;lastLanguage=language;lastPage=page;
  dirty=false;
}
void startSpin() {
  if(spinning) return;
  spinAt=millis(); spinning=true; dirty=true; strcpy(slotMessage,"POWODZENIA!");
  for(int i=0;i<3;i++) {
    reelStart[i]=reelPos[i];
    int target=randomBelow(6);
    // Integer endpoint puts the selected symbol exactly on the payline.
    reelTravel[i]=6*(1+i)+((target-int(reelPos[i])+6)%6);
  }
}
void updateReels(uint32_t now) {
  if(!spinning) return;
  bool finished=true;
  for(int i=0;i<3;i++) {
    float t=min(1.0f,float(now-spinAt)/reelDuration[i]);
    // Cubic ease-out: continuous physical travel with gradual braking.
    float q=1-t; reelPos[i]=reelStart[i]+reelTravel[i]*(1-q*q*q);
    if(t<1) finished=false;
  }
  if(finished) {
    spinning=false; dirty=true;
    for(int i=0;i<3;i++) reelPos[i]=int(lroundf(reelPos[i]))%6;
    bool win=reelPos[0]==reelPos[1]&&reelPos[1]==reelPos[2];
    strcpy(slotMessage,win?"TRZY TAKIE SAME!":"PSH: JESZCZE RAZ");
  }
}
void drawNumbers() {
  int pool[59]; for(int i=0;i<59;i++) pool[i]=i+1;
  for(int i=0;i<6;i++) { int j=i+randomBelow(59-i); int tmp=pool[i]; pool[i]=pool[j]; pool[j]=tmp; lotto[i]=pool[i]; }
  for(int i=0;i<6;i++) for(int j=i+1;j<6;j++) if(lotto[j]<lotto[i]) { int tmp=lotto[i]; lotto[i]=lotto[j]; lotto[j]=tmp; }
  dirty=true;
}
// Encoder edges are collected even while SPI is transferring a frame.
volatile int encoderEdges=0;
volatile uint8_t encoderAB=0;
portMUX_TYPE encoderMux=portMUX_INITIALIZER_UNLOCKED;
void ARDUINO_ISR_ATTR encoderISR() {
  static const int8_t table[16]={0,-1,1,0,1,0,0,-1,-1,0,0,1,0,1,-1,0};
  uint8_t ab=(digitalRead(TRA)<<1)|digitalRead(TRB);
  portENTER_CRITICAL_ISR(&encoderMux);
  encoderEdges+=table[(encoderAB<<2)|ab]; encoderAB=ab;
  portEXIT_CRITICAL_ISR(&encoderMux);
}
bool pressed(int pin,int index,uint32_t now) {
  static bool raw[2]={true,true},stable[2]={true,true};
  static uint32_t changed[2]={0,0};
  bool value=digitalRead(pin);
  if(value!=raw[index]) { raw[index]=value; changed[index]=now; }
  if(now-changed[index]>=25&&value!=stable[index]) { stable[index]=value; return !value; }
  return false;
}
void changePage(int delta,uint32_t now) {
  page=((page+delta)%4+4)%4; sliding=false;pageAt=now;dirty=true;
}
void sampleControls(uint32_t now) {
  bool immediate=mode==WEATHER||mode==MENU||mode==LANGUAGE||mode==COUNTRY;
  bool down=digitalRead(PSH)==LOW;
  HoldAction hold=tetrisHold.poll(down,now,mode==TETRIS);
  if(tetrisHold.consuming()||hold!=HOLD_NONE)pshClicks.cancel();
  if(hold==HOLD_PAUSE)queuedTetrisPause=true;
  if(hold==HOLD_MENU){queuedBack=true;queuedClick=CLICK_NONE;pshClicks.cancel();}
  ClickAction action=pshClicks.poll(down,now,immediate,mode==TETRIS?220:Clicks::WINDOW);
  if(action!=CLICK_NONE)queuedClick=action;
  if(pressed(BAK,1,now))queuedBack=true;
}
void exitToMenu(uint32_t now) {
  mode=(mode==WEATHER||mode==MENU)?WEATHER:MENU;
  spinning=false;sliding=false;queuedTetrisPause=false;pageAt=now;dirty=true;
  for(int i=0;i<3;i++)reelPos[i]=int(lroundf(reelPos[i]))%6;
  strcpy(slotMessage,"PSH: ZAKREC");
  pshClicks.cancel();tetrisHold.reset();queuedClick=CLICK_NONE;inputGuard=true;inputGuardAt=now;
}
void handleInput(uint32_t now) {
  portENTER_CRITICAL(&encoderMux);
  int steps=encoderEdges/4; encoderEdges-=steps*4;
  portEXIT_CRITICAL(&encoderMux);
  steps*=ENCODER_DIRECTION;
  sampleControls(now);
  bool back=queuedBack;queuedBack=false;
  bool pauseBlocks=queuedTetrisPause;queuedTetrisPause=false;
  ClickAction action=queuedClick;queuedClick=CLICK_NONE;
  if(back) {exitToMenu(now);return;}
  if(inputGuard) {
    if(now-inputGuardAt<450) {pshClicks.cancel();return;}
    inputGuard=false;
  }
  if(mode==TETRIS&&pauseBlocks){tetris.togglePause(now);dirty=true;return;}
  if(action==CLICK_DOUBLE) {
    if(mode==TETRIS){tetris.hardDrop(now);dirty=true;}else exitToMenu(now);
    return;
  }
  bool push=action==CLICK_SINGLE;
  if(mode==WEATHER) {
    if(push) { mode=MENU;sliding=false;dirty=true; }
    else if(steps) changePage(steps>0?1:-1,now);
  } else if(mode==MENU) {
    if(steps) { menuIndex=((menuIndex+steps)%10+10)%10; dirty=true; }
    if(push) {
      const Mode targets[]={WEATHER,SLOT,LOTTO,SNAKE,BREAKOUT,PACMAN,INVADERS,TETRIS,LANGUAGE,COUNTRY};
      mode=targets[menuIndex];pageAt=now;dirty=true;
      if(mode==LANGUAGE)choice=language;
      if(mode==COUNTRY)choice=country;
      if(mode==PACMAN)pacman.reset(now,randomBelow);
      if(mode==INVADERS)invaders.reset(now);
      if(mode==TETRIS)tetris.reset(now,randomBelow);
      if(mode==LOTTO)drawNumbers();
      if(mode==SNAKE){snake.reset(now,randomBelow);snake.click(now);}
      if(mode==BREAKOUT){breakout.reset(now);breakout.click(now);}
    }
  } else if(mode==LANGUAGE||mode==COUNTRY) {
    int count=mode==LANGUAGE?2:4;
    if(steps){choice=((choice+steps)%count+count)%count;dirty=true;}
    if(push){
      if(mode==LANGUAGE){language=choice;prefs.putInt("lang",language);}
      else {country=choice;prefs.putInt("country",country);wx=Weather();
        setenv("TZ",countries[country].tz,1);tzset();
        if(requestQueue)xQueueOverwrite(requestQueue,&country);}
      mode=MENU;dirty=true;
    }
  } else if(mode==TETRIS) {
    if(steps){tetris.move(steps,now);dirty=true;}
    if(push){tetris.click(now);dirty=true;}
  } else if(mode==PACMAN) {
    if(steps)pacman.turn(steps>0?1:-1);
    if(push){pacman.click(now);dirty=true;}
  } else if(mode==INVADERS) {
    if(steps){invaders.move(steps);dirty=true;}
    if(push){invaders.click(now);dirty=true;}
  } else if(mode==SNAKE) {
    if(steps)snake.turn(steps>0?1:-1);
    if(push){snake.click(now);dirty=true;}
  } else if(mode==BREAKOUT) {
    if(steps){breakout.move(steps);if(breakout.ready||breakout.paused)dirty=true;}
    if(push){breakout.click(now);dirty=true;}
  } else if(push) { if(mode==SLOT)startSpin();else if(mode==LOTTO)drawNumbers(); }
}
bool fetchWeather(Weather& result,int id) {
  const CountrySpec& site=countries[id];result.countryId=id;
  WiFiClientSecure client;
  // Public weather only. Encryption without certificate authentication.
  client.setInsecure(); client.setHandshakeTimeout(8);
  HTTPClient http; http.useHTTP10(true); http.setConnectTimeout(6000); http.setTimeout(6000);
  String url=String("https://api.open-meteo.com/v1/forecast?latitude=")+site.lat+"&longitude="+site.lon+
    "&current=temperature_2m,relative_humidity_2m,surface_pressure,weather_code,wind_speed_10m,wind_direction_10m,is_day"
    "&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max"
    +String("&timezone=")+site.apiTz+"&forecast_days=3&wind_speed_unit=kmh";
  if(!http.begin(client,url)) return false;
  int status=http.GET();
  if(status!=200) { Serial.printf("Weather HTTP: %d\n",status); http.end(); return false; }
  JsonDocument doc;
  DeserializationError error=deserializeJson(doc,http.getStream());
  http.end();
  if(error) { Serial.println(error.c_str()); return false; }
  JsonObject c=doc["current"],d=doc["daily"];
  const char* fields[]={"temperature_2m","relative_humidity_2m","surface_pressure","weather_code","wind_speed_10m","wind_direction_10m","is_day"};
  for(auto key:fields) if(c[key].isNull()) return false;
  const char* dailyFields[]={"time","weather_code","temperature_2m_max","temperature_2m_min","precipitation_probability_max"};
  for(auto key:dailyFields) if(d[key].size()<3) return false;
  result.temp=c["temperature_2m"]; result.humidity=c["relative_humidity_2m"];
  result.pressure=c["surface_pressure"]; result.wind=c["wind_speed_10m"];
  result.direction=c["wind_direction_10m"]; result.code=c["weather_code"]; result.day=c["is_day"].as<int>()==1;
  if(!isfinite(result.temp)||!isfinite(result.wind)||!isfinite(result.pressure)) return false;
  for(int i=0;i<3;i++) {
    for(auto key:dailyFields) if(d[key][i].isNull()) return false;
    result.days[i].lo=d["temperature_2m_min"][i]; result.days[i].hi=d["temperature_2m_max"][i];
    result.days[i].code=d["weather_code"][i]; result.days[i].rain=d["precipitation_probability_max"][i];
    const char* date=d["time"][i]; if(!date||strlen(date)!=10) return false;
    strlcpy(result.days[i].date,date,sizeof(result.days[i].date));
  }
  result.valid=true; result.received=millis(); return true;
}
void networkTask(void*) {
  WiFi.mode(WIFI_STA); WiFi.setSleep(false); WiFi.setAutoReconnect(true);
  WiFi.begin(WIFI_SSID,WIFI_PASS);
  configTzTime(countries[country].tz,"pool.ntp.org","time.nist.gov");
  uint32_t attempted=0,reconnectAt=millis(); bool first=true;
  uint32_t retry=60000;int requested=country;
  for(;;) {
    uint32_t now=millis();
    if(xQueueReceive(requestQueue,&requested,0)==pdTRUE)first=true;
    if(WiFi.status()==WL_CONNECTED) {
      if(first||now-attempted>=retry) {
        Weather fresh;
        bool ok=fetchWeather(fresh,requested);
        if(ok) { xQueueOverwrite(weatherQueue,&fresh); Serial.println("Weather OK"); }
        attempted=millis(); first=false; retry=ok?600000:60000;
        Serial.printf("Heap: %u / largest: %u\n",ESP.getFreeHeap(),ESP.getMaxAllocHeap());
      }
    } else if(now-reconnectAt>=30000) { WiFi.reconnect(); reconnectAt=now; }
    vTaskDelay(pdMS_TO_TICKS(200));
  }
}
void setup() {
  Serial.begin(115200);
  prefs.begin("kora",false);language=constrain(prefs.getInt("lang",0),0,1);country=constrain(prefs.getInt("country",0),0,3);
  pinMode(TRA,INPUT_PULLUP); pinMode(TRB,INPUT_PULLUP);
  pinMode(PSH,INPUT_PULLUP); pinMode(BAK,INPUT_PULLUP);
  encoderAB=(digitalRead(TRA)<<1)|digitalRead(TRB);
  attachInterrupt(digitalPinToInterrupt(TRA),encoderISR,CHANGE);
  attachInterrupt(digitalPinToInterrupt(TRB),encoderISR,CHANGE);
  spi.begin(SCK_PIN,MISO_PIN,MOSI_PIN,CS);
  tft.begin(40000000); tft.setRotation(0); tft.fillScreen(0);
  g.setTextWrap(false);
  if(!g.pixels.getBuffer()) {
    tft.setCursor(10,100); tft.setTextColor(WHITE); tft.print("Brak RAM: bufor grafiki");
    while(true) delay(1000);
  }
  weatherQueue=xQueueCreate(1,sizeof(Weather));
  requestQueue=xQueueCreate(1,sizeof(int));
  if(!requestQueue||!weatherQueue||xTaskCreate(networkTask,"weather",8192,nullptr,1,nullptr)!=pdPASS)
    Serial.println("Cannot start weather task; dashboard stays offline.");
  pageAt=millis();
}
void loop() {
  uint32_t now=millis();
  handleInput(now); updateReels(now);
  if(mode==SNAKE&&snake.update(now))dirty=true;
  if(mode==BREAKOUT&&breakout.update(now))dirty=true;
  Weather incoming;
  if(weatherQueue&&xQueueReceive(weatherQueue,&incoming,0)==pdTRUE&&incoming.countryId==country){wx=incoming;dirty=true;}
  if(mode==PACMAN&&pacman.update(now))dirty=true;
  if(mode==INVADERS&&invaders.update(now,randomBelow))dirty=true;
  if(mode==TETRIS&&tetris.update(now))dirty=true;
  static uint32_t secondAt=0;
  if(now-secondAt>=1000) {
    secondAt=now; time_t utc=time(nullptr); struct tm tm;
    if(utc>1700000000&&localtime_r(&utc,&tm)) {
      char before[8];strcpy(before,clockText);strftime(clockText,sizeof(clockText),"%H:%M",&tm);if(strcmp(before,clockText)&&mode==WEATHER&&(page==3||page==0))dirty=true;
      strftime(dateText,sizeof(dateText),"%d / %m / %Y",&tm);
    }
    
    static int lastStatus=-1;
    int status=WiFi.status()!=WL_CONNECTED?1:(!wx.valid?2:(now-wx.received>1800000?3:0));
    if(status!=lastStatus){lastStatus=status;if(mode==WEATHER)dirty=true;}
  }
  if(mode==WEATHER&&!sliding&&now-pageAt>=PAGE_MS) changePage(1,now);
  bool arcade=(mode==SNAKE&&!snake.paused&&!snake.over)||(mode==BREAKOUT&&!breakout.paused&&!breakout.ready&&!breakout.over);
  uint32_t interval=(spinning||isArcadeMode(mode))?40:100;
  bool animated=(mode==TETRIS&&!tetris.paused&&!tetris.over)||hasCityBanner(mode)||(mode==SLOT&&spinning)||arcade||(mode==PACMAN&&!pacman.paused&&!pacman.over)||(mode==INVADERS&&!invaders.paused&&!invaders.over);
  if((dirty||animated)&&now-frameAt>=interval) { frameAt=now; render(now); }
  delay(1);
}

