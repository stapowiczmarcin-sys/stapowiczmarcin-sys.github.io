# Fotografie z internetu

Kadry pomniejszone do RGB565, przechowywane we flash.

- London: https://www.pexels.com/photo/30081309/ — https://www.pexels.com/license/
- Warsaw: https://www.pexels.com/photo/18261858/ — https://www.pexels.com/license/
- Madrid: https://www.pexels.com/photo/11807412/ — https://www.pexels.com/license/
- NewYork: https://www.pexels.com/photo/5413931/ — https://www.pexels.com/license/
- Sun: https://www.pexels.com/photo/27679978/ — https://www.pexels.com/license/
- Cloud: https://www.pexels.com/photo/3737447/ — https://www.pexels.com/license/
- Rain: https://www.pexels.com/photo/4702157/ — https://www.pexels.com/license/
- Snow: https://www.pexels.com/photo/6650382/ — https://www.pexels.com/license/
- Wind: https://www.pexels.com/photo/5287942/ — https://www.pexels.com/license/