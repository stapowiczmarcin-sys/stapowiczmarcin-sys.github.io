KORA 5.5: czarne tło i karty prognozy, wspólna strona ciśnienia/wiatru/wilgotności, nowy barometr, grubsze cyfry temperatury i godziny. Zachowane PL/EN, animacje, gry i sterowanie.
