# KORA 5.9 - verification / weryfikacja

EN: Final compilation passed for ESP32-C3 / Huge APP / USB CDC (Espressif 3.3.12). Flash 2,311,571 / 3,145,728 bytes (73%); static/global RAM 41,736 / 327,680 bytes (12%). The strip renderer additionally allocates 7,680 bytes. Compiled headers match the deliverable.

PL: Końcowa kompilacja ESP32-C3 / Huge APP / USB CDC przeszła (Espressif 3.3.12). Flash 2 311 399 / 3 145 728 bajtów (73%); statyczny/globalny RAM 41 728 / 327 680 bajtów (12%). Renderer dodatkowo alokuje 7680 bajtów bufora pasa. Nagłówki użyte do kompilacji odpowiadają paczce.

EN: Actual C++ game logic executed in host tests: seven-piece bags; four orientations; walls; floor rotation; 1, 2, 3, 4 line clears and scores; row collapse; gravity; pause/resume; 300ms lock delay and eight-reset cap; spawn blockage and restart; 100 randomized game sessions; click/double-click/held-button suppression; fixed arcade routing. Software checks confirm birds are no longer country-restricted and the 100px symbol has room beside -99, -20, 0, 14, 99, 100 at unchanged digit height.

PL: Testy uruchomiły rzeczywistą logikę C++: zestawy siedmiu klocków; cztery obroty; ściany; obrót przy podłodze; kasowanie 1-4 linii i punktacja; opadanie pozostałych wierszy; grawitacja; pauza/wznowienie; opóźnienie blokowania 300ms z limitem ośmiu odnowień; zablokowany start i restart; 100 losowych sesji; pojedynczy/dwuklik i wyciszenie kliknięcia po przytrzymaniu; stały wybór sceny gry. Sprawdzono usunięcie ograniczenia ptaków do jednego kraju i odstępy większej ikony przy -99, -20, 0, 14, 99, 100.

EN: No physical TFT, encoder, frame-rate or battery test was performed. Preview game positions and weather values are illustrative. PL: Nie testowano fizycznego TFT, enkodera, liczby klatek ani baterii. Pozycje gry i dane pogodowe w podglądach są ilustracyjne.


## 5.9.1 — button regression
ESP32-C3 compilation passed: 2,311,571 bytes flash (73%); 41,736 bytes static RAM (12%). Native input tests passed: long hold exit, release without accidental selection, medium hold pause, single/double click, debouncing, sparse polling and millis rollover. The hold input route is independent of the ready, playing, paused and game-over game states. Physical encoder testing remains to be performed.
